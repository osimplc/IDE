**This forked code is a stripped and slightly modified version from TinyMultiBootloader+**  
It has only PIC16F887 and 18F4520 microcontrollers identifiers.  
Also, it supports only firmware for PIC16F887 and 18F4520 microcontrollers, running at 20 MHz on external crystal oscillator and 119200 8N1 baudrate/mode.  