window.__searchindex=([
  {
    "title": "OSIMPLC",
    "pagetitle": "OSIMPLC",
    "slug": "index.html",
    "body": "OSIMPLC\n\nOpen Simple Industrial Modular Programmable Logic Controller\n\nÍndice\n\n\nIntroducción\n\n\nMódulo central MCU\n\n\nMódulos de salidas\n\n\nMódulos de expansión\n\n\nMódulo de interacción HMI\n\n\nProgramación y transferencia\n\nLDmicro\nOtros lenguajes\n\n\n\nDocumentación del hardware\n\n\nSoftware\n\nDescargas\nManual LDmicro\nManual OBootLin\n\n\n"
  },
  {
    "title": "Introducción - OSIMPLC",
    "pagetitle": "Introducción - OSIMPLC",
    "slug": "01-home.html",
    "body": "OSIMPLC es un Controlador Lógico Programable de arquitectura abierta (Open Source\nHardware) desarrollado en Argentina con propósitos educativos, y que puede ser aplicado a la\nautomatización de tareas de baja complejidad en entornos productivos industriales,\nagropecuarios y comerciales, y en servicios residenciales, edilicios y urbanos."
  },
  {
    "title": "Open",
    "pagetitle": "Introducción - OSIMPLC",
    "slug": "01-home.html#open",
    "body": "Toda la información relacionada con el diseño de OSIMPLC (esquemáticos, listas de\nmateriales, posicionamiento de componentes, gráficos, tablas auxiliares, etc.) está\ndisponible para su descarga desde su sitio web, bajo licencia Creative Commons\nAttribution-Share Alike, CC BY-SA, permitiendo su libre distribución, reutilización y\nmodificación.\nTodos los softwares recomendados para la programación de OSIMPLC tienen licencia\nlibre GPL o compatible, y toda la documentación original referida a su utilización,\ndisponible en sus correspondientes sitios web, también es de licencia libre."
  },
  {
    "title": "Simple",
    "pagetitle": "Introducción - OSIMPLC",
    "slug": "01-home.html#simple",
    "body": "El hardware de OSIMPLC ha sido desarrollado en base a circuitos integrados y a\ncomponentes activos y pasivos disponibles habitualmente en el mercado local, y que\npueden ser fácilmente adquiridos en comercios minoristas y mayoristas de materiales\nelectrónicos; no requiere importación de componentes bajo demanda.\nLos circuitos impresos que integran los diferentes módulos de OSIMPLC son de\ntecnología de doble capa y agujero pasante metalizado (Two Layer Plated Through Hole\nPCB); y pueden ser fabricados por la mayoría de las empresas del rubro sin complejos\nrequerimientos.\nÉsto permite que OSIMPLC pueda ser construído, montado y/o reparado por el propio\nimplementador o el usuario, facilitando su aplicación en proyectos educativos donde\neventualmente puedan producirse daños por errores de conexión, y también su uso\nentornos productivos, gracias a su menor costo relativo.\nOSIMPLC ofrece las prestaciones básicas que se pueden encontrar en los PLCs de uso\nindustrial; está orientado a resolver tareas con requerimientos acotados de programa y\nmemoria, sin pretender competir con las funcionalidades avanzadas de dichos\nequipamientos."
  },
  {
    "title": "Industrial",
    "pagetitle": "Introducción - OSIMPLC",
    "slug": "01-home.html#industrial",
    "body": "OSIMPLC está diseñado para interactuar con señales industriales normalizadas: trabaja\nsólo bajo tensión de seguridad 24V (opcionalmente 12V para aplicaciones domóticas o\nvehiculares); todas sus entradas y salidas digitales están optoacopladas; sus entradas\nanalógicas soportan señales estándar 0-10V, 0-5V, 0(4)-20mA y pueden también ser\nconfiguradas para conectar directamente sondas PT100, NTC-10K y sensores LDR;\ndispone de una salida analógica configurable en normas 0-10V/0(4)-20mA; ofrece un\npuerto de comunicación con bus RS-485 half-duplex, y una conexión UART-TTL para\ndescarga del programa de usuario mediante adaptador USB/TTL y/o conexión de un\nmódulo HMI Serial TTL.\nLas salidas digitales disponibles en los diferentes módulos cuentan con protecciones integradas:\nseñales de control optoacopladas y limitadores de picos de tensión; y en los\nmódulos especializados de salidas, disponen de portafusibles individuales para cada\nsalida y para alimentación del módulo, haciendo innecesari el requerimiento de\nportafusibles externos.\nTodos los módulos de OSIMPLC cuentan con planos de masa diseñados para minimizar\nlos efectos de interferencias electromagnéticas, disponen de borneras para la conexión de\nseñales de campo (alimentación, entradas, salidas, comunicación), y soportan trabajar\nentre 0 y 55 °C y hasta 95% de humedad sin condensación (condiciones estándar en la\nmayoría de los gabinetes eléctricos industriales)."
  },
  {
    "title": "Modular",
    "pagetitle": "Introducción - OSIMPLC",
    "slug": "01-home.html#modular",
    "body": "El sistema OSIMPLC está basado en módulos que permiten configurarlo de acuerdo a las\ntareas a automatizar, y a las señales de sensores y actuadores requeridas para cada\naplicación específica.\nEl módulo central MCU contiene a bordo el microcontrolador (en dos versiones); doce (12)\nentradas digitales; doce (12) salidas digitales por optoacoplador (una de ellas configurable\ncomo PWM); dos (2) entradas analógicas configurables; puerto RS-485; conector UART-\nTTL; conector ICSP; conectores para módulos de expansión; entrada de alimentación y\nsalidas de tensión de referencia.\nLos diferentes módulos de salidas (cada uno de ellos con cuatro puntos) pueden ser\nfácilmente acoplados al módulo MCU, ofreciendo distintas combinaciones: relés;\ntransistores de potencia; mixto relés/transistor más salida analógica; directas a\noptoacopladores más salida analógica (dedicado a variadores de frecuencia).\nLos módulos de expansión a bordo agregan cuatro señales más, pudiéndose alcanzar\nconfiguraciones máximas de hasta 30 Entradas/Salidas.\nOSIMPLC dispone actualmente de ocho (8) diferentes módulos de expansión con distintas\nconfiguraciones de E/S, algunos de ellos diseñados para resolver aplicaciones específicas\n(detección de líquidos conductivos, sensado de temperaturas).\nEl módulo HMI ofrece una interfaz hombre/máquina simplificada; permite mostrar\nmensajes de texto, variables, efectuar cambio de parámetros, facilitando la interacción del\nusuario con el automatismo."
  },
  {
    "title": "Programmable Logic Controller",
    "pagetitle": "Introducción - OSIMPLC",
    "slug": "01-home.html#programmable-logic-controller",
    "body": "OSIMPLC puede ser fácilmente programado en lenguaje Ladder (IEC 61131-3), mediante\nLDmicro, software libre con licencia GPLv3. Ladder es el lenguaje utilizado más\nhabitualmente para la programación de PLCs industriales.\nOSIMPLC también puede ser programado bajo otros lenguajes no incluídos bajo las\nnormativas IEC 61131-3, como BASIC, C, Assembler, utilizando software libre con licencia\nGPL o compatible: GreatCowBASIC, SDCC + IDE, gputils + editor, u otros.\nEl código máquina compilado en un archivo .hex por LDmicro o por los otros softwares\nlibres disponibles, puede ser fácilmente descargado en OSIMPLC por medio del firmware\nTiny PIC Bootloader (preinstalado) y un conversor serial USB-TTL; o bien directamente\nmediante un programador de PICs, utilizando los softwares de transferencia\ncorrespondientes."
  },
  {
    "title": "OSIMPLC en proyectos educativos",
    "pagetitle": "Introducción - OSIMPLC",
    "slug": "01-home.html#osimplc-en-proyectos-educativos",
    "body": "Gracias a la implementación del lenguaje Ladder (IEC61131-3), al soporte de señales estándar\nen industria, y a la facilidad de su construcción y/o reparación, OSIMPLC resulta un\nequipamiento ideal para la enseñanza de la Automatización Programada en Escuelas de\nEducación Técnica y en Centros de Formación Profesional, en las e specialidades Electricidad,\nElectromecánica y Electrónica.\nLas actividades educativas pueden abarcar desde el montaje de los componentes electrónicos\ny la comprobación de su correcto funcionamiento (utilizando kits “para armar”), hasta el diseño,\nla programación bajo Ladder y el montaje y puesta en funcionamiento de proyectos prácticos\ncomplejos, que incluyan sensores industriales, elementos de maniobra habituales (relés\nelectromecánicos y de estado sólido, contactores, variadores de frecuencia, arrancadores\nsuaves), y los más diversos tipos de accionamientos (motores y motorreductores eléctricos,\nelectroválvulas y actuadores neumáticos y oleohidráulicos, resistencias calefactoras, etc. etc.).\nDe este modo, los educandos pueden integrar y articular la teoría y la práctica, posibilitando\nuna mejor transferencia de lo aprendido a diferentes contextos y situaciones de la actividad\nproductiva real."
  },
  {
    "title": "OSIMPLC en entornos productivos",
    "pagetitle": "Introducción - OSIMPLC",
    "slug": "01-home.html#osimplc-en-entornos-productivos",
    "body": "OSIMPLC puede ser utilizado para implementar automatismos simples en:\n\nMaquinaria y líneas de producción de baja complejidad.\nProcesamiento de alimentos. Control complementario en cámaras frigoríficas, túneles de\ncongelado, autoclaves. Automatización de hornos, secaderos, germinadoras, lavadoras de\nfrutas y hortalizas, estufas de cultivo. Mezcladores, agitadores, amasadoras.\nImpulsión de agua potable, riego programado, ósmosis inversa, sanitizado de aguas.\nConducción y tratamiento de efluentes. Procesamiento de residuos.\nAhorro de energía en calefacción, ventilación y aire acondicionado.\nControl de puertas de seguridad, portones, barreras, persianas y cortinas, rampas vehiculares.\nAutomatización de montacargas, cintas transportadoras, tornillos sinfin.\nIluminación en viviendas, edificios, comercios, industrias, estacionamientos. Alumbrado\npúblico en calles, plazas, estadios, condominios, clubes.\nSeñalización vial, semáforos, guía óptica/acústica de emergencia y/o evacuación.\n… y miles de aplicaciones más!\n"
  },
  {
    "title": "Módulo central MCU - OSIMPLC",
    "pagetitle": "Módulo central MCU - OSIMPLC",
    "slug": "02-mcu.html",
    "body": "El módulo MCU es el núcleo de OSIMPLC; dispone de entradas integradas, conectores a\nmódulos de salidas, a módulos de expansión, y a diversos modos de comunicación y\nprogramación.\nEl módulo MCU contiene a bordo el microcontrolador, en dos versiones fácilmente\nintercambiables:\nPIC16F887 (estándar): puede ser programando en lenguaje Ladder (IEC 61131-3)\nmediante LDmicro, y también en lenguajes BASIC, C y Assembler; aplicable para\nresolución de tareas simples;\nPIC18F4520 (opcional): puede ser programando en lenguajes BASIC, C y Assembler\n(LDmicro no soporta la línea PIC18F). Ofrece el doble de capacidad en memoria para\nprograma de usuario y el cuádruple de capacidad en memoria volátil (RAM) comparado\ncon el PIC16F887; aplicable para resolución de tareas relativamente complejas.\n"
  },
  {
    "title": "Alimentación",
    "pagetitle": "Módulo central MCU - OSIMPLC",
    "slug": "02-mcu.html#alimentacion",
    "body": "Una (1) entrada para alimentación 24Vcc / 12Vcc (rango 11~27Vcc) con protección por\nfusible y contra inversión de polaridad, señalizada por LED;\nTres (3) salidas de tensión de referencia: 0V; 2,5V (máx. 10mA); 5V (máx. 50mA); no\nprotegidas.\n"
  },
  {
    "title": "Entradas",
    "pagetitle": "Módulo central MCU - OSIMPLC",
    "slug": "02-mcu.html#entradas",
    "body": "Doce (12) entradas digitales optoacopladas tipo PNP (sink), en tres grupos de cuatro\nentradas más borne de referencia externa (pueden utilizarse con fuentes de alimentación\nindependientes); señalizadas por LEDs;\n\nDos (2) entradas analógicas no aisladas, configurables por medio de jumpers en las\nnormas 0-10V, 0-5V ó 0(4)-20mA; una de ellas también configurable para conexión de una\nsonda PT100 (provee excitación de 1 mA), la otra también configurable para conexión de\nsensor de temperatura NTC-10K ó sensor LDR.\n"
  },
  {
    "title": "Salidas",
    "pagetitle": "Módulo central MCU - OSIMPLC",
    "slug": "02-mcu.html#salidas",
    "body": "Doce (12) salidas digitales por optoacopladores, de muy baja corriente (máx. 15 mA), una\nde ellas configurable como digital optoacoplada ó como PWM no aislada por medio de\njumpers, con conectores para los módulos especializados de salidas (tres grupos de\ncuatro salidas); señalizadas por LEDs.\n"
  },
  {
    "title": "Expansión",
    "pagetitle": "Módulo central MCU - OSIMPLC",
    "slug": "02-mcu.html#expansion",
    "body": "Dos (2) conectores para módulos de expansión; uno para módulos a bordo (expansiones\nestándar), y el otro para módulos externos diseñados por el propio usuario o bajo pedido.\n"
  },
  {
    "title": "Comunicación",
    "pagetitle": "Módulo central MCU - OSIMPLC",
    "slug": "02-mcu.html#comunicacion",
    "body": "Un (1) puerto RS-485 half-duplex, disponible para conexión con instrumental industrial,\notros controladores programables y/o PC, modo transmisión señalizado por LED;\nUn (1) conector UART-TTL, disponible para descarga del programa de usuario mediante\nbootloader (Tiny Pic Bootloader) y/o monitoreo desde una PC utilizando un conversor\nUSB-TTL, o para conexión del módulo HMI Serial TTL;\n\nUn (1) conector ICSP (In Circuit System Programming) para instalación del bootloader, o\nescritura y lectura del programa de usuario y/o modificación de configuraciones del\nmicrocontrolador, utilizando programadores de PIC como USBPICPROG (Open Hardware + Free Software), PicKit2 u otros.\n\nLa transferencia del código máquina al OSIMPLC puede ser realizada por medio de\ncomunicación serial utilizando un bootloader y un conversor USB-TTL conectado al pin-out\nUART, o por transferencia directa utilizando un programador de PICs conectado al pin-out\nICSP.\n\nNota:\nLa utilización del conector ICSP es excluyente con la utilización de las salidas Y0-Y1; la\nutilización del conector UART-TTL es excluyente con la conexión del puerto RS-485.\n"
  },
  {
    "title": "OSIMPLC provee como accesorio un cable de programación USB-TTL",
    "pagetitle": "Módulo central MCU - OSIMPLC",
    "slug": "02-mcu.html#osimplc-provee-como-accesorio-un-cable-de-programacion-usb-ttl",
    "body": ""
  },
  {
    "title": "Módulos de salidas - OSIMPLC",
    "pagetitle": "Módulos de salidas - OSIMPLC",
    "slug": "03-outs.html",
    "body": "Las salidas a señales de campo industriales de OSIMPLC están disponibles por medio de\nmódulos acoplables de cuatro salidas.\nDichas salidas son aptas para comandar actuadores o equipamientos de maniobra intermedios\nque funcionen sólo bajo tensión de seguridad (24V), no estando permitido conectar elementos\nque trabajen en tensión de red.\nOSIMPLC MCU dispone de tres puertos, Y0-Y3, Y4-Y7 y Y8-YB/PWM, para conexión directa\nde los módulos de salidas; algunos de éstos (sólo con salidas digitales) pueden ser conectados\nindistintamente a cualquiera de los tres puertos, mientras que otros módulos (con salida\nanalógica o PWM) sólo pueden ser conectados al puerto Y8-YB/PWM.\nTodos los módulos de salidas requieren de alimentación externa, disponen de fusible para su\ncircuito de control, y de fusibles de protección en cada una de sus salidas digitales (excepto en\nmódulo para control de variador de frecuencia), y en su salida analógica, en aquellos en que\nestá presente.\nLas salidas digitales cuentan con protecciones limitadas contra sobretensiones en alimentación\ny picos de tensión inversa originados por la desconexión de cargas inductivas.\nNo obstante, el usuario deberá instalar las protecciones externas corresponientes a este tipo de\ncargas (red RC, varistor, para cargas inductivas en CA; diodo de de rueda libre para cargas\ninductivas en CC)."
  },
  {
    "title": "O4R: MÓDULO DE SALIDAS A RELÉS",
    "pagetitle": "Módulos de salidas - OSIMPLC",
    "slug": "03-outs.html#o4r:-modulo-de-salidas-a-reles",
    "body": "Cuatro (4) salidas a relé, contacto NA, Unom: 24 Vca/cc; Imax: 2A carga resistiva, 1A\ncarga inductiva.\nAlimentación del módulo: 24Vcc (estándar), 12Vcc (O4R-12, a pedido). Puede compartir la\nalimentación con el módulo MCU, o utilizar fuente independiente.\n"
  },
  {
    "title": "O4T: MÓDULO DE SALIDAS A TRANSISTORES DE POTENCIA",
    "pagetitle": "Módulos de salidas - OSIMPLC",
    "slug": "03-outs.html#o4t:-modulo-de-salidas-a-transistores-de-potencia",
    "body": "Cuatro (4) salidas a transistor tipo NPN colector abierto (MOSFET canal N), Unom: 24\nVcc; Imax: 2A carga resistiva, 1A carga inductiva.\nAlimentación del módulo: 24V/12 Vcc, configurable por jumper. Puede compartir la\nalimentación con el módulo MCU, o utilizar fuente independiente.\n"
  },
  {
    "title": "OMX: MÓDULO DE SALIDAS MIXTO, RELEŚ + TRANSISTOR + SALIDA ANALÓGICA",
    "pagetitle": "Módulos de salidas - OSIMPLC",
    "slug": "03-outs.html#omx:-modulo-de-salidas-mixto-reles-+-transistor-+-salida-analogica",
    "body": "Dos (2) salidas a relé, contacto NA, Unom: 24 Vca/cc; Imax: 2A carga resistiva, 1A carga\ninductiva.\nUna (1) salida a transistor NPN colector abierto, Unom: 24 Vcc; Imax: 200 mA carga\nresistiva, 100 mA carga inductiva.\nUna (1) salida analógica, configurable como 0-10V / 0(4)-20mA, resolución máx. 10 bits.\nAlimentación del módulo: 24Vcc. Puede compartir la alimentación con el módulo MCU, o\nutilizar fuente independiente.\n"
  },
  {
    "title": "OVF: MÓDULO PARA CONTROL DE VARIADOR DE FRECUENCIA",
    "pagetitle": "Módulos de salidas - OSIMPLC",
    "slug": "03-outs.html#ovf:-modulo-para-control-de-variador-de-frecuencia",
    "body": "Tres (3) salidas para conexión directa de las de entradas digitales del variador de\nfrecuencia a los optoacopladores en el módulo MCU. Pueden utilizarse indistintamente\ncon señales PNP o NPN. No protegidas por fusible.\nUna (1) salida analógica, normas 0-10V / 0(4)-20mA, resolución máx. 10 bits.\nAlimentación del módulo: 24Vcc. Puede compartir la alimentación con el módulo MCU, o\nutilizar fuente independiente.\n"
  },
  {
    "title": "EN DESARROLLO",
    "pagetitle": "Módulos de salidas - OSIMPLC",
    "slug": "03-outs.html#en-desarrollo",
    "body": ""
  },
  {
    "title": "ODCM: MÓDULO PARA CONTROL DE UN MOTOR EN CC",
    "pagetitle": "Módulos de salidas - OSIMPLC",
    "slug": "03-outs.html#odcm:-modulo-para-control-de-un-motor-en-cc",
    "body": "Salidas de Puente H, corriente hasta 10A en 24Vcc, más una (1) salida a transistor tipo\nNPN colector abierto (MOSFET canal N), Unom: 24 Vcc; Imax: 2A carga resistiva, 1A\ncarga inductiva; inversión de rotación, control de velocidad por PWM, frenado/rueda libre\ndel motor, accionamiento de freno electromecánico."
  },
  {
    "title": "Módulos de expansión - OSIMPLC",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html",
    "body": "Los módulos de expansión a bordo permiten agregar más entradas y salidas al sistema,\nllegando hasta configuraciones de 18E/12S, 16E/14S ó 14E/16S (30 puntos).\nLa mayoría de los módulos reciben alimentación desde el módulo MCU, con excepciones en\nciertos módulos especializados."
  },
  {
    "title": "MÓDULOS DE ENTRADAS",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#modulos-de-entradas",
    "body": ""
  },
  {
    "title": "E4AI",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#e4ai",
    "body": "Cuatro (4) entradas analógicas normalizadas, configurables individualmente en las\nnormas 0-10V, 0-5V ó 0(4)-20mA por medio de jumpers.\n"
  },
  {
    "title": "E4DI",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#e4di",
    "body": "Cuatro (4) entradas digitales, configurables individualmente como PNP (sink) o NPN\n(source) por medio de jumpers, señalizadas por LEDs.\n"
  },
  {
    "title": "E2AI2DI",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#e2ai2di",
    "body": "Dos (2) entradas analógicas normalizadas, configurables individualmente en las normas 0-\n10V, 0-5V ó 0(4)-20mA por medio de jumpers; más dos (2) entradas digitales,\nconfigurables individualmente como PNP (sink) o NPN (source) por medio de jumpers,\nseñalizadas por LEDs.\n"
  },
  {
    "title": "E4TI",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#e4ti",
    "body": "Expansión especializada para sensado de temperatura.\nDos (2) entradas para conexión de sondas PT100 (provee excitación de 1 mA para cada\nuna de ellas); más dos (2) entradas para conexión de sondas NTC-10K.\n"
  },
  {
    "title": "E4CI",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#e4ci",
    "body": "Expansión especializada para detección de líquidos conductivos.\nCuatro (4) entradas digitales de muy baja corriente en CA, señalizadas por LEDs; provee\ntensión de excitación en 12 Vca @ 900 Hz (minimizando la hidrólisis) por medio de bornes\npara conexión de electrodos de referencia. Las señales enviadas al microcontrolador\nestán invertidas respecto a la detección del líquido.\n\n\nAtención: este módulo requiere alimentación externa en 24Vcc; puede compartir la\nalimentación con el módulo MCU, o utilizar fuente independiente.\n"
  },
  {
    "title": "MÓDULO DE SALIDAS",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#modulo-de-salidas",
    "body": ""
  },
  {
    "title": "E4DO",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#e4do",
    "body": "Cuatro (4) salidas a transistor NPN colector abierto, Umax: 24 Vcc; Imax: 200 mA carga\nresistiva, 100 mA carga inductiva, señalizadas por LEDs (ver Nota).\n"
  },
  {
    "title": "MÓDULOS MIXTOS DE ENTRADAS Y SALIDAS",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#modulos-mixtos-de-entradas-y-salidas",
    "body": ""
  },
  {
    "title": "E2AI2DO",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#e2ai2do",
    "body": "Dos (2) entradas analógicas normalizadas, configurables individualmente en las normas 0-\n10V, 0-5V ó 0(4)-20mA por medio de jumpers; más dos (2) salidas a transistor NPN\ncolector abierto, Umax: 24 Vcc; Imax: 200 mA carga resistiva, 100 mA carga inductiva,\nseñalizadas por LEDs (ver Nota).\n"
  },
  {
    "title": "E2DI2DO",
    "pagetitle": "Módulos de expansión - OSIMPLC",
    "slug": "04-expansions.html#e2di2do",
    "body": "Dos (2) entradas digitales, configurables individualmente como PNP (sink) o NPN (source)\npor medio de jumpers, señalizadas por LEDs; más dos (2) salidas a transistor NPN\ncolector abierto, Umax: 24 Vcc; Imax: 200 mA carga resistiva, 100 mA carga inductiva,\nseñalizadas por LEDs (ver Nota).\n\n\nNota:\nLos módulos de expansión no disponen de fusibles de protección en sus salidas individuales,\nlos que deberán ser instalados externamente por el usuario.\n\nLas salidas cuentan con protecciones limitadas contra sobretensiones en alimentación y picos\nde tensión inversa originados por la desconexión de cargas inductivas; el usuario deberá\ninstalar las protecciones adicionales correspondientes a cada tipo de cargas (red RC, varistor,\npara cargas en CA; diodo de de rueda libre para cargas en CC)."
  },
  {
    "title": "Módulo de interacción HMI - OSIMPLC",
    "pagetitle": "Módulo de interacción HMI - OSIMPLC",
    "slug": "05-hmi.html",
    "body": "El módulo HMI (Human Machine Interface) está diseñado para facilitar la interacción del usuario\ncon el automatismo; permite mostrar mensajes de texto para alarma o información, estados de\nentradas y salidas digitales, variables numéricas (valores escalados de entradas analógicas,\ntemporizadores, contadores, variables internas, etc.), efectuar modificaciones en los\nparámetros de trabajo, y ejecutar comandos de control.\nConsiste en un display LCD de 2 filas por 16 caracteres con retroiluminación y de cuatro\npulsadores programables, no dispone de memoria propia; y se comunica con el módulo MCU\npor medio de bus serial TTL, siendo apto para ser montado a corta distancia del OSIMPLC, p.\nej. en el frente de gabinete.\nLa interacción entre el módulo MCU y el módulo HMI se controla por medio de operaciones\nUART en norma 96008N desde el programa de usuario cargado en el microcontrolador,\nsoportando un subconjunto básico de comandos seriales tipo Matrix Orbital.\nEn caso de estar instalado en el módulo MCU el microcontrolador PIC16F887 y de\ndesarrollarse la programación bajo Ladder con el software LDmicro, su capacidad de\ninteracción será considerablemente limitada, debiendo ser cuidadosamente optimizada por el\nprogramador.\nLas posibilidades de interacción se verán notablemente incrementadas en caso de instalarse\nen el módulo MCU el microcontrolador PIC18F4520 y realizarse la programación en BASIC, C\no Assembler, aprovechando bibliotecas y funciones especializadas disponibles en dichos\nlenguajes.\n\nNOTA:\nEl módulo HMI no es un panel de operador (OP) de tipo industrial; no dispone actualmente de\nenvolvente o gabinete con grado de protección IP (en desarrollo).\n"
  },
  {
    "title": "Programación y transferencia - OSIMPLC",
    "pagetitle": "Programación y transferencia - OSIMPLC",
    "slug": "06-environments.html",
    "body": "OSIMPLC requiere dos entornos diferentes para su utilización:\n\nEntorno de programación, en el que se desarrollará la aplicación (programa de usuario) y se\nprocederá a su compilación en código máquina (archivo .hex).\nEntorno de transferencia, que efectúa la descarga en el microcontrolador del código máquina\ncompilado por el entorno de programación.\n\nOSIMPLC puede ser programado bajo cualquier software que soporte los microcontroladores\nPIC16F887 (estándar) y/o PIC18F4520 (alternativo), y genere códico máquina en archivos .hex\n(I8HEX).\nDichos softwares pueden ser de licencia libre (Free Software GPL, BSD, MIT, o compatibles),\nde licencia privativa gratuita (MPLAB u otros), o de licencia privativa paga.\nSin embargo, siendo OSIMPLC un proyecto Open Hardware + Free Software, recomendamos\núnicamente su utilización con software de licencia libre, y no brindaremos soporte para ninguna\naplicación o desarrollo basado en software privativo."
  },
  {
    "title": "ENTORNOS DE PROGRAMACIÓN RECOMENDADOS",
    "pagetitle": "Programación y transferencia - OSIMPLC",
    "slug": "06-environments.html#entornos-de-programacion-recomendados",
    "body": "LADDER (IEC 61131-3): LDmicro, licencia GPLv3\nOtros lenguajes no incluídos en normativa IEC61131-3:\n\n\nBASIC: Great Cow Basic, licencia GPLv2, LGPLv2.\n\n\nC: SDCC, licencia GPLv2 o GPLv3, + IDE (Code::Blocks, Eclipse, otros).\n\n\nASSEMBLER: gpasm (suite gputils), licencia GPLv2, + editor de texto (sobre GNU/Linux se puede utilizar Geany como IDE).\n\n"
  },
  {
    "title": "ENTORNOS DE TRANSFERENCIA RECOMENDADOS",
    "pagetitle": "Programación y transferencia - OSIMPLC",
    "slug": "06-environments.html#entornos-de-transferencia-recomendados",
    "body": "La transferencia del código máquina al OSIMPLC puede ser realizada, ya sea por medio de\ncomunicación serial utilizando un bootloader, el conector UART y un conversor USB-TTL, o por transferencia directa utilizando un programador de PICs, utilizando cualquier hardware y su\ncorrespondiente software que soporte los antedichos microcontroladores."
  },
  {
    "title": "1. TRANSFERENCIA SERIAL: SOFTWARE, FIRMWARE, HARDWARE",
    "pagetitle": "Programación y transferencia - OSIMPLC",
    "slug": "06-environments.html#1.-transferencia-serial:-software-firmware-hardware",
    "body": ""
  },
  {
    "title": "Software para GNU/Linux",
    "pagetitle": "Programación y transferencia - OSIMPLC",
    "slug": "06-environments.html#software-para-gnulinux",
    "body": "OBootLin: licencia GPLv2, basado en Python3.\nPre-requisitos: deberá instalar como dependencias python3-serial y python3-wxphython,\nprovistos por su distribución.\n\nNota:\nEste software, disponible como OBootlin en el área de descargas, es una modificación del\nsoftware tinybldlin (fork lcgamboa) para su utilización con OSIMPLC; sus directorios contienen\núnicamente los módulos identificadores y los bootloaders para PIC16F887 y PIC18F4520 con\ncristal oscilador de 20 MHz y norma de comunicación serial 19200-8N1.\n"
  },
  {
    "title": "Software para Windows",
    "pagetitle": "Programación y transferencia - OSIMPLC",
    "slug": "06-environments.html#software-para-windows",
    "body": "Tiny Multi Bootlader+: Licencia Creative Commons Attribute - No Comercial (CC BY-NC)\nEste software permite la descarga del código máquina en diversas líneas de\nmicrocontroladores. Lea las instrucciones de instalación y uso en su sitio web."
  },
  {
    "title": "Firmware",
    "pagetitle": "Programación y transferencia - OSIMPLC",
    "slug": "06-environments.html#firmware",
    "body": "Los firmwares de Tiny PIC Bootloader para PIC16F887y PIC18F4520, pre-instalados en los\nmicrocontroladores de OSIMPLC, han sido modificados para su compatibilidad con cristal\noscilador de 20 MHz y norma de comunicación serial 19200-8N1."
  },
  {
    "title": "Hardware",
    "pagetitle": "Programación y transferencia - OSIMPLC",
    "slug": "06-environments.html#hardware",
    "body": "El proyecto OSIMPLC provee un cable de programación que incluye el conversor USB-TTL\nbasado en chipset CH340 ó CH341, y un terminal zócalo hembra ya dispuesto para conexión\ncon el pin-out UART de OSIMPLC.\nSin embargo, el usuario puede, bajo su propia responsabilidad, utilizar un conversor USB-TTL\ngenérico y construir su propio cable de programación con los terminales adecuados.\nLos modernos sistemas operativos GNU/Linux (kernel >=4.0) y Windows (8 / 10) ya incluyen los\ndrivers para los conversores USB-TTL basados en los chipsets CH340, CH341, CP2102,\nFTDI232 y Prolific2303.\nEn caso de que el S.O. no disponga de dichos drivers, se debe consultar al proveedor del\nconversor USB-TTL acerca del chipset incluído y el driver recomendado para ese componente."
  },
  {
    "title": "2. TRANSFERENCIA DIRECTA (HARDWARE PROGAMADOR DE PICs)",
    "pagetitle": "Programación y transferencia - OSIMPLC",
    "slug": "06-environments.html#2.-transferencia-directa-(hardware-progamador-de-pics)",
    "body": "OSIMPLC recomienda el uso de USBPICPROG, programador por puerto USB, Open Hardware + Free Software\nEl código máquina compilado por el Entorno de Programación (archivo .hex) puede ser\ntransferido a OSIMPLC por medio de su conector ICSP, utilizando USBPICPROG y un cable\ncon el pin-out adecuado.\nEl software de USBPICPROG se distribuye con licencia GPLv2, puede descargarse el código\nfuente para GNU/Linux, e instaladores para la distribución Ubuntu, Windows y MacOSX.\nPara la distribución Arch Linux, está disponible en AUR el PKGBUILD que permite la compilación de USBPICPROG, escrito por propio desarrollador de OSIMPLC.\nUSBPICPROG dispone de una versión de hardware basada en circuito impreso doble capa y\nagujero pasante (Two Layer Through Hole PCB), y componentes electrónicos estándar\ndisponibles en el mercado local, por lo que puede ser construído y montado por el propio\nusuario.\n\nNota:\nLa transferencia directa del código máquina a OSIMPLC, por medio de un programador de\nPICs, sobreescribirá (borrará) el bootloader pre-instalado.\nEn caso de requerirse la reinstalación del bootloader para habilitar nuevamente la\nprogramación serial, deberá utilizarse el programador para transferir previamente el firmware\ncorrespondiente al modelo de microcontrolador instalado por medio de ICSP.\n"
  },
  {
    "title": "LDmicro - OSIMPLC",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html",
    "body": "LDmicro es el software recomendado para el uso de OSIMPLC en entornos educativos, ya que\nfacilita el aprendizaje del lenguaje de programación para PLCs más habitual en entornos\nindustriales: LADDER (IEC 61131-3).\nTambién es el software más conveniente para el rápido desarrollo de aplicaciones simples\ndestinadas a entornos productivos, gracias a su editor gráfico simplificado, las instrucciones\nestándar integradas, fácil configuración de puntos de Entradas/Salidas y módulos de\nexpansión, y disponibilidad de rutinas de comunicación básicas.\nEl microcontrolador PIC16F887 incluído en OSIMPLC (estándar) está plenamente soportado\npor LDmicro, no así el microcontrolador PIC18F4520 (alternativo), cuyo juego de instrucciones\nes diferente y debe ser programado utilizando otros lenguajes: BASIC, C, Assembler.\nLDmicro corre nativamente sobre Windows; y también sobre GNU/Linux bajo Wine, sin\nnecesidad de utilizar DLL externas o no libres.\nLDmicro no requiere instalación, simplemente descargar el archivo, descomprimirlo en un\ndirectorio y ejecutar el .exe correspondiente. Dispone de distintos ejecutables con la traducción\nde los menús y diálogos a diversos idiomas, incluído por supuesto el español."
  },
  {
    "title": "Instrucciones disponibles en LDmicro",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#instrucciones-disponibles-en-ldmicro",
    "body": "Contactos y bobinas, normales e invertidos.\nEvaluación de flanco ascendente (positivo) y descendente (negativo).\nOperaciones sobre bobinas: Set, Reset, Trigger (telerruptor).\nLectura de entradas analógicas (ADC).\nControl de salida PWM.\nTemporizadores: a la Conexión, a la Desconexión, de Impulso, Retentivo, Cíclico.\nContadores: Ascendente, Descendente, Bidireccional, Cíclico, Slow Quad Encoder.\nOperaciones aritméticas en variables con signo: suma, resta, multiplicación, división,\nmódulo, negación, mover variable.\nOperaciones de comparación sobre variables con signo: >, <, =, >=, <=, !=.\nOperaciones bit-a-bit sobre variables sin signo: AND, OR, NOT, XOR, desplazamiento\nlineal y cíclico, inversión, swap.\nOperaciones sobre bits individuales en variables: Test Bit Set, Test Bit Clear, Set Bit,\nClear Bit.\nOperaciones especiales con variables: direccionamiento indirecto, desplazamiento de\nvariable indexada, linearización, tabla de búsqueda, generación de número aleatorio,\npersistencia de variable (escritura en EEPROM).\nOperaciones de conversión: BIN <-> BCD.\nOperaciones de control del programa: Master Control Relay, GOTO, GOSUB y\ncomplementarias, SLEEP, DELAYuS, CLRWDT.\nOperaciones de comunicación sobre UART: enviar cadena de caracteres y/o variable,\nrecibir carácter, enviar carácter, control de buffers.\nLDmicro permite compilar el programa de usuario (aplicación) desarrollado bajo Ladder\ngenerando un archivo .hex que contiene el código máquina para algunos dispositivos de dos\nlíneas de microcontroladores de 8 bits: Microchip PIC y AVR Atmega; y en una versión\nderivada, también para un microcontrolador STM32F40X ARM de 32 bits.\nAdemás, LDmicro permite generar código en Assembler, C, PASCAL, Interpretable Byte Code,\nSketch para Arduino."
  },
  {
    "title": "Simulación",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#simulacion",
    "body": "LDmicro habilita la simulación de la ejecución del programa de aplicación en la PC, sin\nnecesidad de compilar y descargar el código máquina en el microcontrolador, facilitando así la\ncorrección del programa desarrollado en lenguaje Ladder.\nSin embargo, esa herramienta debe utilizarse con precaución, ya que la simulación no puede\nreproducir en su totalidad las subrutinas y tiempos de ejecución de las microinstrucciones\nnativas del controlador."
  },
  {
    "title": "VERSIONES DE LDMICRO",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#versiones-de-ldmicro",
    "body": ""
  },
  {
    "title": "ORIGINAL",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#original",
    "body": "LDmicro fue desarrollado inicialmente por Jonathan Wuesthues en el año 2005, quien mantuvo\nsus actualizaciones hasta la versión v2.3 (02/01/2016).\nLDmicro es Free Software y fue desarrollado bajo licencia GPL versión 3, por lo que el libre\nuso, distribución, y modificación del código fuente y de los ejecutables está garantizada.\nEl sitio web http://cq.cx/ladder.pl contiene valiosa información sobre instalación y uso del\nprograma, tutoriales, notas técnicas, y links para descarga de la versión v2.3 y anteriores.\nEn su foro http://cq.cx/ladder-forum.pl , una activa comunidad de usuarios intercambia\ninformación, difunde ejemplos de programación, responde consultas, y es una fuente\ninestimable para la resolución de problemas en el uso del programa y en la implementación de\naplicaciones."
  },
  {
    "title": "ACTUAL",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#actual",
    "body": "LDmicro es actualmente mantenido por Ihor Nehrutsa, quien ha agregado soporte para nuevos\nmicrocontroladores PIC y AVR Atmega, e implementaciones como Arduino y Controllino Maxi,\nademás de muchas nuevas funciones en Ladder y características avanzadas.\nEl desarrollo de LDmicro se realiza actualmente en el sitio https://github.com/LDmicro/LDmicro ;\nla descarga del código fuente y los ejecutables puede hacerse desde https://github.com/LDmicro/LDmicro/releases\nIhor Nehrutsa mantiene también una importante wiki en https://github.com/LDmicro/LDmicro/wiki , allí encontrará valiosa información sobre las nuevas\nfunciones, ejemplos, métodos, tutoriales, etc."
  },
  {
    "title": "DERIVADAS",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#derivadas",
    "body": "Actualmente hay una versión derivada (fork) de LDmicro: LDmicro32, desarrollada por José\nGilles en https://github.com/joegil95 .\nEn este nuevo desarrollo, José Gilles ha añadido nuevas funciones para comunicaciones\nutilizando los buses I2C y SPI en microcontroladores PIC, AVR y ARM (sólo disponibles\ncompilando el Ladder en código intermedio en C). Además, ha resuelto el bug de\nsimulación de la versión v4.4.3.0 y ha reordenado los menús del programa de modo\nmás funcional.\nLDmicro32 añade soporte para el microcontrolador STM32F407 ARM de 32 bits, para el cual\nel programa genera código intermedio en C, para luego compilar en código máquina\nutilizando el compilador libre ARM-GCC (externo).\nLa última versión de este fork puede ser descargada desde\nhttps://github.com/joegil95/LdMicro32/"
  },
  {
    "title": "INSTALACIÓN",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#instalacion",
    "body": ""
  },
  {
    "title": "Microsoft Windows",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#microsoft-windows",
    "body": "\nDescargue el archivo .zip de la versión de LDmicro de su preferencia y\ndescomprímalo en una carpeta de su directorio personal.\nAbra dicha carpeta y ejecute mediante doble click el .exe compilado con el lenguaje\nde su preferencia. Opcionalmente, puede crear un acceso directo al ejecutable en su\nescritorio y/o en otra/s carpeta/s.\n"
  },
  {
    "title": "GNU/Linux",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#gnulinux",
    "body": "\nPre-requisitos:\nSi utiliza un S.O. de 64 bits, habilite las bilbliotecas multiarquitectura de Intel 32 bits\nen su sistema (siguiendo las instrucciones de su distribución). Efectúe una actualización\ncompleta de su sistema.\nSi utiliza un S.O. de 32 bits, no es necesario ejecutar este paso.\nMediante el gestor de paquetes de su S.O., instale el programa wine provisto por su\ndistribución.\nUtilizando una terminal virtual como usuario, cree y configure en 32 bits el prefijo\nwine por defecto:\n$ WINEARCH=win32 winecfg\nSerá creado el directorio /home/$USER/.wine , conteniendo dos subdirectorios:\n/dosdevices (links a dispositivos) y /drive_c (ejecutables de wine, programas,\nconfiguraciones, etc. etc.).\nDescargue el archivo .zip de la versión de LDmicro de su preferencia y\ndescomprímalo en una carpeta de su directorio personal.\nUtilizando su gestor de archivos, lance el ejecutable de LDmicro en el lenguaje de su\npreferencia mediante doble click. El sistema ejecutará LDmicro bajo el entorno wine.\nOpcionalmente, utilizando un editor de textos, puede crear un lanzador\nLDmicro.desktop en su escritorio y/o en otro/s directorio/s:\n\n[Desktop Entry]\nName=LDmicro\nExec=env WINEPREFIX=\"/home/$USER/.wine\" wine\n/ruta/al/ejecutable/LDmicro/ldmicroxxx.exe\nType=Application\nStartupNotify=true\nPath=/ruta/al/directorio/LDmicro/\nIcon=/ruta/al/archivo/ldmicro.png (creado o seleccionado por el usuario)\n"
  },
  {
    "title": "DESCARGA",
    "pagetitle": "LDmicro - OSIMPLC",
    "slug": "07-ldmicro.html#descarga",
    "body": "La descarga de la versión recomendada de LDmicro está directamente disponible desde el sitio web de OSIMPLC, es aquella que a nuestro entender brinda mayor estabilidad y mejores\nprestaciones (instrucciones integradas, organización de menús, etc.).\nSin embargo, el usuario puede optar por utilizar cualquiera de las otras versiones\ndescargándolas directamente desde su sitio web, a condición de que en caso de consultas\ntécnicas por mal funcionamiento, falta de funcionalidad o cualquier otro tipo de inconveniente,\nconsigne claramente la versión del software que está utilizando.\nEl manual de LDmicro está incluído en el ejecutable, también es posible descargarlo como un\narchivo .txt independiente.\nRENUNCIA DE GARANTIA Y LIMITACION DE RESPONSABILIDAD\nLDmicro es software libre bajo licencia GPLv3, por lo que en lo referido a garantía y\nresponsabilidad legal se aplican todas las consideraciones de dicha licencia.\nAdemás, de acuerdo a lo declarado por su desarrollador Jonathan Westhues: “no use LDmicro\npara nada que sea crítico para la seguridad, o algo que rompa cualquier cosa cara si fallara”.\nPor supuesto, NO debe utilizar LDmicro en conjunto con OSIMPLC en ningún caso en que\npudiere verse afectada la seguridad, la salud o la vida de las personas."
  },
  {
    "title": "Otros lenguajes - OSIMPLC",
    "pagetitle": "Otros lenguajes - OSIMPLC",
    "slug": "08-otherlangs.html",
    "body": ""
  },
  {
    "title": "Lenguaje BASIC",
    "pagetitle": "Otros lenguajes - OSIMPLC",
    "slug": "08-otherlangs.html#lenguaje-basic",
    "body": "Great Cow BASIC (GCB), licencia GPLv2, LGPLv2.\n\n“Great Cow BASIC tiene tres objetivos principales: eliminar la necesidad de repetitivos\ncomandos en Assembler, producir código eficiente, y facilitar tomar el código escrito para un\ntipo de microcontrolador y ejecutarlo en otro tipo de microcontrolador”.\n\n\n“Great Cow BASIC es adecuado para principiantes, para quienes no les gusta o no desean\naprender el lenguaje Assembler, y para programadores experimentados con\nmicrocontroladores”.\n\nInstalado sobre Windows incluye GCB@Syn IDE, un editor de texto integrado basado en\nSynWrite (licencia MPL v1.1); sobre GNU/Linux se puede utilizar GCB Compiler con Geany\ncomo IDE (requier Freebasic como dependencia), o ejecutarlo bajo wine.\nGCB dispone de extensas bibliotecas integradas para dispositivos externos, y permite al\nusuario incluir sus propias bibliotecas. Además, permite insertar código desarrollado en\nAssembler dentro del código en BASIC.\nGCB cuenta con una extensa ayuda online, facilitando el aprendizaje y el uso del lenguaje\nBASIC, y del programa y sus bibliotecas."
  },
  {
    "title": "Lenguaje C",
    "pagetitle": "Otros lenguajes - OSIMPLC",
    "slug": "08-otherlangs.html#lenguaje-c",
    "body": "Small Device C Compiler (SDCC), licencia GPLv2 o GPLv3, + IDE.\n\n\"SDCC es un compilador optimizador del Estándar C (ANSI C89, ISO C99, ISO C11) que se\nenfoca en los microprocesadores basados en Intel MCS51, Maxim DS80C390, Freescale\nbasados en HC08, MCU basadas en Zilog Z80 y STMicroelectronics STM8.\nEl soporte de los microcontroladores Microchip PIC16 y PIC18 en un trabajo en progreso\".\n\nLa suite SDCC es una colección de varios componentes derivados de diferentes fuentes con\ndiferentes licencias Free Open Source Software.\nSDCC no provee un IDE nativo, pero es plenamente soportado por Code::Blocks en su versión\nV17.2, y por Eclipse IDE por medio de un plugin."
  },
  {
    "title": "Lenguaje ASSEMBLER",
    "pagetitle": "Otros lenguajes - OSIMPLC",
    "slug": "08-otherlangs.html#lenguaje-assembler",
    "body": "gpasm (suite gputils), licencia GPLv2, + editor de texto.\nLa suite gputils incluye gpasm, un compilador para Assembler desde línea de comandos (no\ndispone de GUI). Puede utilizarse con Geany como IDE: tiene una función de resaltado de\nsintaxis para Assembler, y acepta gpasm como compilador desde su menú Build."
  },
  {
    "title": "How To…",
    "pagetitle": "Documentación del hardware - OSIMPLC",
    "slug": "09-hardware.html#how-to...",
    "body": "\nHowTo: Analog Inputs\nHowTo: Analog Inputs Expansion Module\nHowTo: Conductive Liquids Inputs Expansion Module\nHowTo: Digital Inputs Expansion Module\nHowTo: Digital PNP Inputs\nHowTo: Digital Power Transistor NPN Outputs\nHowTo: Digital Relay Outputs\nHowTo: Digital Transistor NPN Outputs Expansion Module\nHowTo: Frequency Drive Outputs\nHowTo: Mixed Outputs\nHowTo: OSIMPLC HMI Commands\nHowTo: OSIMPLC PIC IO Points\nHowTo: Programming USB ICSP\nHowTo: Serial Ports RS-485 TTL\nHowTo: Temperature Inputs Expansion Module\n"
  },
  {
    "title": "Schematics",
    "pagetitle": "Documentación del hardware - OSIMPLC",
    "slug": "09-hardware.html#schematics",
    "body": "\nE2AI2DI\nE2AI2DO\nE2DI2DO\nE4AI\nE4CI\nE4DI\nE4DO\nE4TI\nHMI\nMCU\nO4R\nO4T\nOMX\nOVF\n"
  },
  {
    "title": "FAB",
    "pagetitle": "Documentación del hardware - OSIMPLC",
    "slug": "09-hardware.html#fab",
    "body": "\nE2AI2DI\nE2AI2DO\nE2DI2DO\nE4AI\nE4CI\nE4DI\nE4DO\nE4TI\nHMI\nMCU\nO4R\nO4T\nOMX\nOVF\n"
  },
  {
    "title": "Manual LDmicro - OSIMPLC",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html",
    "body": ""
  },
  {
    "title": "Implementación en OSIMPLC",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#implementacion-en-osimplc",
    "body": "\nEsta traducción del manual de LDmicro al español ha sido editada específicamente para su utilización con OSIMPLC, en base al contenido del archivo manual.txt en inglés provisto con la descarga de la versión v.5.3.0.1 de LDmicro.\nEsta edición pretende corregir, ampliar y mejorar la traducción original del manual en español, provista como manual-es.txt en dicha versión del programa.\nAl editar la presente versión, se ha modificado la organización en la presentación de los diferentes ítems, en particular la referida a las diferentes instrucciones Ladder implementadas por LDmicro.\nEl objetivo de esta reorganización ha sido presentar las diferentes instrucciones agrupándolas en función del tipo de proceso o actividad que ejecutan, y por la complejidad en su implementación.\nTambién se han simplificado algunos de los gráficos complementarios incluídos en modo texto, para permitir su completa edición en formato Markdown (.md), y para facilitar la generación de código HTML para su presentación en la web sin requerir hipervínculos a archivos de imágenes externos.\n"
  },
  {
    "title": "INTRODUCCION",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#introduccion",
    "body": "LDmicro genera código nativo para ciertos Microcontroladores Microchip PIC16 y Atmel AVR.\nPor lo general, el software para estos microcontroladores está escrito en lenguaje de programación como ensamblador, C o BASIC.\nUn programa en uno de estos lenguajes comprende una lista de enunciados.\nEstos lenguajes son potentes y bien  adaptados a la arquitectura del procesador, que ejecuta internamente una lista de instrucciones.\nLos PLCs, por otro lado, se programan a menudo en Ladder, lenguaje “escalera” o “de contactos”.\nUn programa simple desarrollado en Ladder podría verse así:\n   ||                                                                    ||\n   ||    Xbutton1           Tdon           Rchatter           Yred       ||\n   ||-------]/[---------[TON 1.000 s]-+-------]/[--------------( )-------||\n   ||                                 |                                  ||\n   ||    Xbutton2           Tdof      |                                  ||\n   ||-------]/[---------[TOF 2.000 s]-+                                  ||\n   ||                                                                    ||\n   ||                                                                    ||\n   ||                                                                    ||\n   ||    Rchatter            Ton             Tnew           Rchatter     ||\n   ||-------]/[---------[TON 1.000 s]----[TOF 1.000 s]---------( )-------||\n   ||                                                                    ||\n   ||                                                                    ||\n   ||                                                                    ||\n   ||------[END]---------------------------------------------------------||\n   ||                                                                    ||\n   ||                                                                    ||\n\nEn el ejemplo, TON es un retardo a la activación, TOF es un retardo a la desactivación, los símbolos --], [-- y --]/[-- son entradas de señal lógica que se comportan como los contactos de un relé, los símbolos --( )-- son salidas de señal lógica que se comportan como la bobina de un relé.\nExisten buenas referencias para la lógica de contactos, disponibles libremente en Internet.\nLos detalles específicos de esta implementación en LDmicro se explican a continuación.\nSon evidentes las siguientes diferencias:\n\n\nEl programa se presenta en formato gráfico, no como una lista textual de instrucciones.\nMuchas personas inicialmente encontrarán ésto más fácil de entender.\n\n\nEn el nivel más básico, los programas parecen diagramas de circuito, con contactos de relé (entradas) y bobinas (salidas).\nEsto resulta más intuitivo para los programadores con conocimiento de teoría de circuitos eléctricos.\n\n\nEl compilador lógico del lenguaje de contactos se encarga de cuándo, dónde y cómo se deben recalcular los estados del sistema.\n\n\nNo es necesario escribir código para determinar cuándo las salidas deben actualizarse p. ej. sobre la base de un cambio en las entradas o en un temporizador, y no es necesario especificar el orden en que estos cálculos deben tener lugar.\nLas herramientas del PLC hacen eso por usted.\nLDmicro compila lógica de contactos para PIC16 o código AVR. Los siguientes microcontroladores son soportados:\n\nPIC16F628\nPIC16F628A\nPIC16F876\nPIC16F877A\nPIC16F88\nPIC16F819\nPIC16F886\nPIC16F887\nATmega8\nATmega16\nATmega32\nATmega64\nATmega128\nATmega162\nATmega1284P\nATmega2560\n\nVerifique la lista de microcontroladores soportados mediante el menú Configuraciones > Microcontrolador. La lista para versiones >= v.5.3.0 es mucho más extensa, e incluye algunos microcontroladores AVR AT90 y ARM STM32.\n\nConsulte en el foro de LDmicro el estado de soporte para las diversas líneas y modelos de microcontroladores. Es habitual que se incorporen más modelos al liberar una nueva versión.\n\nUsando LDmicro, puede diseñar un diagrama de contactos para su programa. Usted también puede simular la ejecución en tiempo real de la lógica en su PC. Una vez que esté convencido que el diagrama es correcto, puede asignar pines en el microcontrolador a la entradas y salidas del programa.\nUna vez que haya asignado los pines, puede compilar el código PIC o AVR para su programa. La salida del compilador es un fichero hexadecimal *.hex,  archivo que puede descargar en su microcontrolador utilizando cualquier programador PIC / AVR.\nLDmicro está diseñado para ser similar a la mayoría de los sistemas de programación de PLC comerciales. Hay algunas excepciones, y muchas cosas no son estándar en la industria de todos modos.\nLea atentamente la descripción de cada instrucción, aunque le parezca familiar. Este documento presupone el conocimiento básico de la lógica de contactos y de la estructura del software del PLC (ciclo de ejecución: lectura de entradas, cálculo, escritura de salidas).\nVer LDmicro Wiki - PLC and safety y LDmicro Wiki - PLC Cycle Time 0"
  },
  {
    "title": "OBJETIVOS ADICIONALES",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#objetivos-adicionales",
    "body": "Con LDmicro también es posible generar código ANSI C. Usted podría usar ésto con cualquier procesador para el que se disponga de un compilador C, pero usted es responsable de suministrar el ciclo de ejecución (runtime).\nÉsto significa que LDmicro sólo genera fuentes para la función PlcCycle(). Usted es responsable de llamar a PlcCycle en cada ciclo, y usted es responsable de implementar todas las E/S (lectura de Entradas/ escritura, etc.) que la función PlcCycle() llama. Vea los comentarios en la fuente generada para obtener más detalles.\nPor último, LDmicro puede generar bytecode independiente del procesador para un máquina virtual diseñada para ejecutar código de lógica de contactos.\nHe proporcionado un ejemplo de implementación del intérprete / VM, escrito en C estandard. Esta meta funcionará para casi cualquier plataforma, siempre y cuando usted pueda suministrar su propia VM. Esto podría ser útil para aplicaciones en las que desea usar la lógica ladder como un “lenguaje de scripting” para personalizar un programa. Vea los comentarios en el ejemplo de intérprete para más detalles.\nSe ha añadido un nuevo objetivo “Controllino Maxi / Ext bytecode”. Genera un archivo .xint interpretable por el software de PLC LDuino. Hasta ahora sólo el controlador Maxi PLC es soportado. Sin embargo, como el bytecode es genérico, se podría hacer la adaptación a cualquier otro PLC o tarjeta de la CPU. Vea el código fuente de LDuino para eso."
  },
  {
    "title": "OPCIONES EN LINEA DE COMANDOS",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#opciones-en-linea-de-comandos",
    "body": "ldmicro.exe normalmente se ejecuta sin opciones desde la línea de comandos.\nÉsto significa que basta con hacer un acceso directo al programa o guardarlo en su escritorio, y hacer doble click en el ícono cuando desee ejecutarlo; a continuación, puede realizar toda la tarea de programación, asignación y compilación dentro del Entorno Gráfico de Usuario de LDmicro.\nSi en la línea de comandos se pasa a LDmicro un nombre de archivo único (por ejemplo, ‘ldmicro.exe asd.ld’), entonces LDmicro intentará abrir el archivo “asd.ld”, si existe. Se produce un error si “asd.ld” no existe.\nÉsto significa que se puede asociar ldmicro.exe con archivos .ld, para que se ejecute automáticamente al hacer doble click en un archivo .ld.\nSi se pasa argumentos de línea de comandos a LDmicro en la forma Ldmicro.exe / c src.ld dest.hex, entonces el ejecutable intenta compilar src.ld, y guarda la salida como dest.hex\nLDmicro finaliza después de compilar, tanto si la compilación resultó exitosa o no. Los mensajes se imprimen en la consola. Este modo sólo es útil cuando se ejecuta LDmicro desde línea de comandos.\nSi se ejecuta LDmicro sin argumentos, se comienza con un archivo de programa vacío. Si se ejecuta LDmicro con el nombre de un programa de lenguaje de contactos (xxx.ld) en la línea de comandos, entonces se intentará cargar ese programa en el inicio.\n"
  },
  {
    "title": "CONCEPTOS BASICOS",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#conceptos-basicos",
    "body": "LDmicro utiliza su propio formato interno para el programa; no puede importar lógica de cualquier otra herramienta o programa equivalente.\nSi no se cargó un programa ya existente, al ejecutar LDmicro se iniciará un programa con un diagrama de contactos vacío.\nPuede modificar el programa insertando o eliminando instrucciones.\nEl cursor en la pantalla del programa parpadea para indicar la instrucción y el punto de inserción actual. Si no está parpadeando entonces pulse la tecla Tab o haga clic en una instrucción. Ahora puede borrar o puede insertar una nueva instrucción a la derecha o a la izquierda (en serie con), o por encima o por debajo (en paralelo con), la instrucción seleccionada.\nAlgunas operaciones no están permitidas, por ejemplo, no hay instrucciones a la derecha de una bobina de salida.\nEl programa comienza con una sola línea (escalón, rung). Puede agregar más escalones seleccionando Insertar Línea Antes | Después en el menú Editar.\nPodría obtener el mismo resultado lógico colocando muchos subcircuitos complicados en paralelo en un línea, pero es más claro utilizar múltiples líneas (escalones).\nUsted puede agregar instrucciones; por ejemplo puede agregar un conjunto de contactos (menú Instrucción -> Insertar contactos) denominados “Xnew”.\n“X” en este caso significa que el contacto estará vinculado a un pin de entrada en el Microcontrolador. Puede asignarle el pin correspondiente más adelante, después de seleccionar el modelo del microcontrolador y cambiar el nombre de los contactos.\nLa primera letra de un nombre (variable) indica qué tipo de objeto es."
  },
  {
    "title": "Variables (objetos) actuales en LDmicro",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#variables-(objetos)-actuales-en-ldmicro",
    "body": "\nXname - X: pin de entrada digital en el microcontrolador\nYname - Y: pin de salida digital en el microcontrolador\nRname - R: relay interno o marca, un bit en la memoria del microcontrolador\nTname - T: temporizado a la conexión, a la desconexión, acumulativo, etc.\nCname - C: contador incremental, decremental, circular, etc.\nAname - A: variable de un entero leída desde un convertidor A/D\nPname - P: salida PWM en el microcontrolador\nMname - M: bobina discreta MODBUS\nIname - I: entrada discreta MODBUS\nHname - H: registro Holding MODBUS\nName - nombre: variable de uso general (un entero con signo). Tipos actualmente soportados: byte, word, word+nibble, dword; 1, 2, 3 y 4 bytes.\n\nIMPORTANTE:\n\nLos nombres de las variables pueden consistir en letras, números y subrayados “_”.\nEl nombre de una variable no debe comenzar con un número.\nEn los nombres de variables se distinguen mayúsculas y minúsculas (case sensitive).\n\nElija el resto del nombre de la variable para que describa convenientemente lo que hace el objeto, y de modo que sea único dentro del programa.\nEl mismo nombre siempre se refiere al mismo objeto dentro del programa.\nPor ejemplo, sería un error tener un retardo a la conexión (TON) llamado “Tespera” y un retardo a la desconexión (TOF) llamado también “Tespera” en el mismo programa, ya que cada temporizador necesita su propio espacio de memoria.\nPor otro lado, sería correcto tener un temporizador retentivo (RTO) llamado “Tsumar” y una instrucción de restablecimiento (RES) asociada con “Tsumar”, ya que en este caso se desea que ambas instrucciones trabajen con el mismo temporizador."
  },
  {
    "title": "Direccionamiento directo e indirecto a los registros del microcontrolador",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#direccionamiento-directo-e-indirecto-a-los-registros-del-microcontrolador",
    "body": "\nUn nombre de variable que comienza con el símbolo ‘#’ como  #PORTA, #PORTB, #PORTC, … es tratado como puerto de salida del hardware.\nUn nombre de variable que comienza con el símbolo ‘#’ como #PINA, #PINB, #PINC, … es tratado como puerto de entrada del hardware.\nUn nombre de variable que comienza con el símbolo ‘#’ como #TRISA, #TRISB, #TRISC, …  es tratado como registro de dirección de datos de puertos correspondientes #PORTA, #PORTB, #PORTC, …\nUn nombre de variable que comienza con un carácter ‘#’ y un número subsecuente (comúnmente un hexadecimal) es tratado como la dirección explícita (directa) del correspondiente registro en el hardware.\nUn nombre de variable que comienza con un carácter ‘#’ y un nombre de variable de uso general es tratado como un puntero (direccionamiento indirecto a un registro del hardware). Variables como  #VarName son la dirección indirecta de un registro (Indirect Address Pointer).\n\n\nPor ejemplo:\n\n{MOV  portAddr:=}  ; portAddr es una variable de uso general a la que se le asigna el valor 0x05.  \n--{0x05}--  \n{MOV #portAddr:=}   ; portAddr es tratada como el puntero indirecto al registro #0x05 PORTA.  \n--{0xF0}--  ; los pines en PORTA (salidas) son escritos con el valor binario 11110000.  \n\n¡Tenga cuidado al escribir en los registros del hardware mediante el acceso directo a sus direcciones!\nVer LDmicro Wiki - Indirect addressing\nLas instrucciones disponibles para variables generales (MOV, ADD, EQU, etc.) pueden ejecutarse sobre variables con cualquier nombre, inclusive las que comienzan con T (temporizadores), C (contadores).\nÉsto significa que pueden acceder a objetos como temporizadores y a contadores para realizar operaciones (comparaciones, aritméticas, etc.) con los valores actuales de sus variables.\nA veces ésto puede ser muy útil; por ejemplo, usted podría comprobar si el conteo de un temporizador está dentro de un rango determinado.\nLas variables siempre se tratan como enteros con signo. Usted puede especificar literales como números decimales normales (10, 1234, -56). También puede especificar códigos de carácter ASCII (‘A’, ‘z’, ‘5’, etc.) colocando el carácter en comillas simples. Puede utilizar un código ASCII en la mayoría de los lugares en que puede utilizar un número decimal.\nPuede también utilizar números hexadecimales (0xA, 0x04D2, 0xffc8), números octales (0o12, 0o2322, 0o177710), o números binarios (0b1010, 0b10011010010, 0b1111111111001000), en la mayoría de los lugares en los que podría utilizar un número decimal.\nLDmicro utiliza los prefijos del lenguaje C:\n\n0x__ ó 0X__ para números hexadecimales con dígitos 0123456789ABCDEF\n0o__ ó 0O__ o 0__ números octales con dígitos 01234567\n0b__ ó 0B__ para números binarios con dígitos 01\n\n\nNota: la notación binaria y la hexadecimal resultan más adecuadas para las operaciones bit a bit.\n"
  },
  {
    "title": "Actualización: Versiones >= v.4.3.0",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#actualizacion:-versiones-greater-v.4.3.0",
    "body": "Las variables pueden alojar números enteros con signo de 1, 2, 3 ó 4 bytes.\nVersiones anteriores sólo trabajan con variables de 2 bytes, con rango -32768 ~ +32767.\nSe puede cambiar el tamaño de la variable (alcance, span) mediante doble click en su nombre en la lista de variables en la zona inferior de la ventana de LDmicro.\nLas variables son almacenadas y procesadas en la forma de complemento a 2.\nVer Two’s complement\nAlcance de las variables:\nBytes|   Tipo       |        Rango desde               |            hasta                 |\n   1 | signed int8  | -2^7  = -128 = 0x80              | 2^7 -1 = 127 = 0x7F              |\n   2 | signed int16 | -2^15 = -32768 = 0x8000          | 2^15-1 = 32767 = 0x7FFF          |\n   3 | signed int24 | -2^23 = -8388608 = 0x800000      | 2^23-1 = 8388607 = 0x7FFFFF      |\n   4 | signed int32 | -2^31 = -2147483648 = 0x80000000 | 2^31-1 = 2147483647 = 0x7FFFFFFF |\n\nEl valor decimal cero (0) es representado por los bits 00…000\nEl valor decimal menos uno (-1) es representado por los bits 11…111\nLas variables con signo int8 (byte) pueden ser utilizadas para que el archivo .hex resulte más pequeño y rápido de ejecutar.\nLas variables con signo int16 (entero, integer, word) pueden ser utilizadas habitualmente para operaciones aritméticas y con los valores obtenidos de la lectura de los ADC, y son compatibles con versiones de LDmicro previas a v.4.3.0.\nLas variables con signo int24 y int32 (dword) pueden ser utilizadas para ampliar el rango de la operación, a costa de incrementar considerablemente el tamaño del archivo .hex y hacer más lenta la ejecución del código máquina en el microcontrolador.\nLa extensión del signo para variables de diferentes tamaños es proporcionada automáticamente en LDmicro.\n\nNota: las instrucciones MUL, DIV, MOD, no pueden procesar variables int32 con signo.\n"
  },
  {
    "title": "Marca de desbordamiento",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#marca-de-desbordamiento",
    "body": "La marca de desbordamiento (Overflow|Underflow ó Carry/Borrow) es provista como el relé interno ROverflowFlagV en LDmicro.\nVer Overflow_flag y Binary-overflow\nLa marca de desbordamiento ROverflowFlagV indica que el resultado en complemento a dos de una operación con signo (aritmética, asignación, etc.) no cabe en el número de bits utilizado en la variable de destino de la operación, y señala un error que debe ser resuelto por el usuario.\nPor ejemplo, si a una variable del tipo int8 (byte) dest = 127 (0x7f) se le agrega 1, se obtiene -128 (0x80), y la marca de desbordamiento ROverflowFlagV será establecida en 1.\nPor el contrario, si a una variable int16 (word) dest = 127 (0x007f) se le agrega 1, se obtiene 128 (0x0080), y la marca de desbordamiento ROverflowFlagV no será afectada.\nLDmicro repone a 0 la marca de desbordamiento ROverflowFlagV durante la inicialización (Power On o Reset por software o hardware).\n\nNota: CTC genera un impulso de sobrellenado (Overfill Carry) cuando Counter==Max.\nCTR genera un impulso de sobrellenado (Overfill Borrow) cuando Counter==Min.\nOverfill (Carry|Borrow) no establece a 1 la marca de desbordamiento ROverflowFlagV.\n"
  },
  {
    "title": "Marca de cambio de signo",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#marca-de-cambio-de-signo",
    "body": "La marca de cambio de signo (traslapo) es provista como el estado de salida de las operaciones suma (ADD) y resta (SUB).\nLa marca de superposición indica que ha cambiado el signo en el resultado de la operación.\nPor ejemplo, ocurre traslapo cuando a -1 (0xf…f) se le suma 1 (o se le resta -1),se obtendrá 0 (0x0…0), todos los dígitos en uno (1 )en la variable cambian a cero (0).  También ocurre traslapo cuando a 0 (0x0…0) se le resta 1 (o se le suma -1), se obtendrá 1 (0xF…F), todos los dígitos en cero (0) cambian a uno (1).\nOtro ejemplo: ocurre traslapo cuando a -10 se le suma 15 (o se le resta -15), se obtendrá 5; la variable origen negativa cambiará a un resultado positivo. También ocurre traslapo cuando a 10 se le resta 15 (o se le suma -15), se obtendrá -5; la variable origen positiva cambiará a un resultado negativo.\n"
  },
  {
    "title": "SIMULACION",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#simulacion",
    "body": "Una vez que haya escrito un programa, puede probarlo en simulación, y luego puede compilarlo en un archivo .hex para el microcontrolador de destino.\nPara entrar en el modo de simulación, seleccione Simular -> Modo de simulación o pulse las teclas Ctrl+M o F7.\nEl programa se muestra de forma diferente en el modo de simulación. Ya no está visible el cursor.\nLas instrucciones que están activadas aparecen en rojo, las instrucciones que están desactivadas aparecen en gris.\nPresione la barra espaciadora para ejecutar un ciclo del PLC.\nPara realizar un ciclo continuo en tiempo real, seleccione Simular -> Iniciar Simulación en tiempo real, o presione las teclas Ctrl+R ó F8. La visualización del programa se actualizará en tiempo real, a medida que cambien los estados de contactos, bobinas, temporizadores, contadores u otros objetos presentes en el programa.\nPuede configurar el estado de las entradas de señal en el programa (pines de entrada en el microcontrolador) haciendo doble click en la lista en la parte inferior de la ventana, o haciendo doble click en el nombre del contacto correspondiente “Xname” en el programa en Ladder.\nSi desea que una entrada adopte el valor 1 (ON, True) automáticamente al inicio de la simulación, preceda dicha entrada con el símbolo ^.\nSi cambia el estado de un pin de entrada, ese cambio no se reflejará en la visualización del programa hasta que el PLC ejecute un nuevo ciclo.\nÉsto sucedera automáticamente si está ejecutando una simulación en tiempo real, o cuando presione la barra espaciadora si está simulando la ejecución ciclo por ciclo.\n"
  },
  {
    "title": "COMPILANDO A CODIGO MAQUINA",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#compilando-a-codigo-maquina",
    "body": "En última instancia, el objetivo de la programación bajo LDmicro es generar el código máquina que se pueda descargar en la memoria del microcontrolador para ser ejecutado por el mismo.\nPara ello, se debe generar el archivo .hex (formato Intel IHEX) mediante la compilación del esquema Ladder. El archivo .hex contendrá código intermedio que permitirá grabar las distintas posiciones de las memorias del microcontrolador (Flash, programa; EEPROM, datos; Config Bits, configuración) utilizando un programador (“quemador”) con hardware y software específicos."
  },
  {
    "title": "SELECCION DEL MICROCONTROLADOR",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#seleccion-del-microcontrolador",
    "body": "En primer término, deberá seleccionar el modelo del microcontrolador en el menú  Configuración -> Microcontrolador.\nTenga muy en consideración que algunos modelos de microcontroladores actualmente soportados por LDmicro son comercializados en diferentes formatos (DIP, QFP, etc.).\nEn caso de utilizar un microcontrolador compatible en algún formato diferente al presentado en la lista, asigne las entradas y salidas en el programa de usuario a los pines correspondientes de acuerdo a su función, Puerto y número dentro del mismo; no las asigne según el número de pin en la huella (footprint) del circuito integrado."
  },
  {
    "title": "CONFIGURACIÓN DE PARÁMETROS DEL MICROCONTROLADOR",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#configuracion-de-parametros-del-microcontrolador",
    "body": "A continuación deberá configurar los parámetros de trabajo del microcontrolador en el menú Ajustes -> Parámetros MCU …\nDeberá configurar el tiempo de ciclo con el que va a ejecutar el programa (ciclo de PLC), y deberá indicarle al compilador con qué frecuencia base funcionará el microcontrolador (frecuencia del cristal externo u oscilador).\nEn general, usted no necesitará cambiar el tiempo del ciclo preestablecido; 10 ms es un buen valor para la mayoría de las aplicaciones. Sin embargo, para tareas que requieren alta velocidad en el procesamiento de entradas/salidas, tiempo de ciclos menores pueden resultar provechosos. Por otra parte, si el programa contiene una muy gran cantidad de instrucciones, tiempos de ciclo mayores pueden permitir la ejecución sin que resulte truncada por el temporizador de control WDT.\nEscriba la frecuencia del cristal (o el resonador cerámico, etc.) que va a usar con el microcontrolador. Ésta frecuencia base será la utilizada para que el compilador calcule las rutinas de temporizadores y otras rutinas internas.\nSi se han programado instrucciones que operen comunicación de datos por UART, también deberá definir la velocidad de transmisión y recepción (baudrate).\nEn las versiones actuales de LDmicro, también podrá establecer los bits de configuración para microcontroladores de la línea PIC (aceptando ó modificando el valor por defecto generado por LDmicro), y los bits de configuración de los microcontroladores de la línea AVR .\nAdemás, deberá establecer la frecuencia de los buses SPI e I2C, en caso de utilizar las correspondientes instrucciones en el programa de usuario."
  },
  {
    "title": "ASIGNACION DE PINES A ENTRADAS Y SALIDAS DIGITALES, Y A ENTRADAS ANALOGICAS",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#asignacion-de-pines-a-entradas-y-salidas-digitales-y-a-entradas-analogicas",
    "body": "En la parte inferior de la ventana verá una lista conteniendo todos los objetos del programa (contactos, bobinas, temporizadores, contadores, variables generales, etc. etc.).\nEsta lista se genera automáticamente desde el programa, no hay necesidad de mantenerla actualizada manualmente.\nLa mayoría de los objetos no necesita de ninguna configuración. Sin embargo, los objetos “Xname” (entrada digital), “Yname” (salida digital) y “Aname” (variable de lectura de ADC) deben ser obligatoriamente asignados a un pin en el microcontrolador.\nPrimero deberá elegir en el menú Configuración -> Microcontrolador qué modelo de microcontrolador será utilizado, y a continuación deberá asignar los pines de E/S haciendo doble click en los objetos en la lista.\nLuego deberá asignar un pin de E/S a cada objeto “Xname”, “Yname” y “Aname”.\nPuede hacerlo mediante doble click en el nombre del objeto en la lista en la parte inferior de la ventana. Aparecerá un cuadro de diálogo mostrando una lista con la identificación de cada uno de los pines y sus posibles funciones, en la que podrá elegir un pin aún no asignado.\nLos pines destinados a comunicación UART y PWM son asignados automáticamente por LDmicro en función del microcontrolador seleccionado.\nSi desea remover la asignación de un objeto a un determinado pin para reasignarlo a otro, selecciónelo y asígnele el valor “(no pin)” que se muestra en la primer línea en la lista, luego selecciónelo nuevamente y asígnele el nuevo pin deseado.\n\nNOTA: PULL UP RESISTORS\nTenga muy en consideración, al diseñar su hardware y/o editar el programa de usuario, todas las configuraciones de resistencias internas (pull up resistors) que LDmicro establece por defecto en los pines asigados a entradas digitales en algunos puertos de los microcontroladores PIC y AVR.\n\nVer:\n\nPull up resistors\nDisable Pull up resistors\nPull down resistors\n"
  },
  {
    "title": "COMPILACION",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#compilacion",
    "body": "Ahora puede generar código desde su programa. Elija Compilar -> Compilar, o Compilar -> Compilar Como … si ha compilado previamente este programa y desea especificar un nombre de archivo de salida diferente (variante).\nSi no hay errores, LDmicro generarará un archivo Intel IHEX listo para la programación (descarga) en su microcontrolador.\nUtilice cualquier hardware y software de programación que disponga para cargar el archivo hexadecimal en el microcontrolador.\n¡Recuerde establecer los fusibles (bits) de configuración!\nPara los procesadores PIC16, los bits de configuración están incluídos en el fichero .hex, y la mayoría del software de programación automáticamente buscará allí su configuración.\nIMPORTANTE: Para procesadores AVR, debe establecer los bits de configuración manualmente.\n"
  },
  {
    "title": "REFERENCIA DE INSTRUCCIONES",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#referencia-de-instrucciones",
    "body": "Terminología:\n\n“Activado por Nivel” = la salida lógica del objeto es controlada por el nivel lógico leído en la entrada del mismo (ON = 1; OFF = 0).\n“Activado por Flanco” = la salida lógica del objeto cambia sólo en en el instante en que la entrada lógica cambia de un valor a otro. El cambio puede ser activado por el flanco positivo (cambio de 0 a 1) o activado por el flanco negativo (cambio de 1 a 0).\nLa mayoría de los objetos de LDmicro son “Activados por Nivel”, algunos objetos son “Activados por Flanco”, p. ej. los contadores modifican el valor de su variable Cnt sólo al presentarse un flanco positivo en su entrada lógica (OBSOLETO, válido para versiones previas a la v.4.4.0).\n\n"
  },
  {
    "title": "CONTACTO NORMALMENTE ABIERTO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#contacto-normalmente-abierto",
    "body": "         Xname         Yname        Rname  \n      ----] [----   ----] [----  ----] [----  \n\nEsta instrucción examina el estado de un pin de entrada, un pin de salida, o un relé interno (marca). Si la señal en su entrada es 0 (OFF, False), entonces la señal en su salida es 0 (OFF, False). Si la señal en su entrada es 1 (ON, True), entonces la señal en su salida es 1 (ON). Si y sólo si el pin de entrada, pin de salida o relé interno está en 1 (ON, True), la salida será 1 (ON, True), de lo contrario será 0 (OFF, False).\nInstrucción Activada por Nivel.\n"
  },
  {
    "title": "CONTACTO NORMALMENTE CERRADO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#contacto-normalmente-cerrado",
    "body": "        Xname         Yname         Rname  \n      ---]/[----   ----]/[----   ----]/[----  \n\nEsta instrucción examina el estado de un pin de entrada, un pin de salida, o un relé interno (marca). Si la señal en su entrada es 0 (OFF, False), entonces la señal en su salida es 1 (ON, True). Si la señal en su entrada es 1 (ON), entonces la señal en su salida es 0 (OFF). Si y sólo si el pin de entrada, pin de salida o relé interno está en 0 (OFF, False), la salida será 1 (ON, True), de lo contrario será 0 (OFF, False). Esta instrucción es la opuesta a la de un contacto normalmente abierto.\nInstrucción Activada por Nivel.\n"
  },
  {
    "title": "BOBINA NORMAL",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#bobina-normal",
    "body": "         Yname         Rname  \n      ----( )----   ----( )----  \n\nEsta instrucción controla el estado de salidas físicas (pines) y relés internos (marcas) del microcontrolador. Si la señal en su entrada es 0 (OFF, False), entonces el estado en su salida es 0 (OFF, False). Si la señal en su entrada es 1 (ON, True), entonces el estado en su salida es 1 (ON, True).\nEsta instrucción debe ser siempre programada en el extremo derecho del escalón (rung). Instrucción Activada por Nivel.\n"
  },
  {
    "title": "BOBINA INVERTIDA",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#bobina-invertida",
    "body": "         Yname         Rname  \n      ----(/)----   ----(/)----  \n\nEsta instrucción controla el estado de salidas físicas (pines) y relés internos (marcas) del microcontrolador. Si la señal en su entrada es 0 (OFF, False), entonces la señal en su salida es 1 (ON, True). Si la señal en su entrada es 1 (ON, True), entonces la señal en su salida es 0 (OFF, False). Esta instrucción es la opuesta a la de un una bobina normal.\nEsta instrucción debe ser siempre programada en el extremo derecho del escalón (rung). Instrucción Activada por Nivel.\n"
  },
  {
    "title": "ACTIVAR BOBINA (SET)",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#activar-bobina-(set)",
    "body": "         Yname         Rname  \n      ----(S)----   ----(S)----  \n\nEsta instrucción controla el estado de salidas físicas (pines) y relés internos (marcas) del microcontrolador.\nSi la señal en su entrada lógica es 1 (ON, True), entonces el estado del relé interno o del pin de salida pasa a ser 1 (ON, True) y se mantiene en ese estado.\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), el estado del relé interno o del pin de salida no cambia.\nUna vez que la bobina está activada (SET), el mantenimiento o la aparición de sucesivas señales en 1 en su entrada lógica no cambiarán el estado de la salida lógica de la bobina.\nEsta instrucción sólo puede cambiar el estado de salida de una bobina de 0 (OFF, False) a 1 (ON, True), por lo que es típicamente utilizada en combinación con una bobina RESET.\nEsta instrucción debe ser siempre programada en el extremo derecho del escalón (rung). Instrucción Activada por Nivel.\n"
  },
  {
    "title": "DESACTIVAR BOBINA (RESET)",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#desactivar-bobina-(reset)",
    "body": "         Yname         Rname  \n      ----(R)----   ----(R)----  \n\nEsta instrucción controla el estado de salidas físicas (pines) y relés internos (marcas) del microcontrolador.\nSi la señal en su entrada es 1 (ON, True), entonces el estado del relé interno o el pin de salida pasa a ser 0 (OFF, False) y se mantiene en ese estado.\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), el estado del relé interno o del pin de salida no cambia.\nUna vez que la bobina está desactivada (RESET), el mantenimiento o la aparición de sucesivas señales en 1 en su entrada lógica no cambiarán el estado de la salida lógica de la bobina.\nEsta instrucción sólo puede cambiar el estado de salida de una bobina de 1 (ON, True) a 0 (OFF, False), por lo que es típicamente utilizada en combinación con una bobina SET.\nEsta instrucción debe ser siempre programada en el extremo derecho del escalón (rung). Instrucción Activada por Nivel.\n"
  },
  {
    "title": "BOBINA TELERRUPTOR",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#bobina-telerruptor",
    "body": "         Yname         Rname  \n      ----(T)----   ----(T)----  \n\nEsta instrucción controla el estado de salidas físicas (pines) y relés internos (marcas) del microcontrolador.\nUna Bobina T (Trigger) es un telerruptor (conmutador, flip-flop) gobernado por flanco positivo. El estado de la salida de la bobina cambia al estado opuesto ante cada flanco positivo (ascendente) leído en su entrada, es decir en el instante en que la señal en su entrada lógica pasa 0 (OFF, False) a 1 (ON, True), y mantiene ese nuevo estado hasta que se detecte un nuevo flanco ascendente en la señal de entrada.\nEsta instrucción debe ser siempre programada en el extremo derecho del escalón (rung). Instrucción Activada por Flanco (positivo).\n                          |   La duración de la señal 1 en la entrada\n                          |   debe ser mayor al tiempo de ciclo del PLC                                                       \n                          |\n                T Trigger |     __       ___________      >_<  t > 1 PLC CYCLE  ___\n                   input  | ___/  \\_____/           \\_____/ \\__________________/\n                          |    |        |                 |                    |\n                T Trigger |    v________v                 v____________________v\n                  output  | ___/        \\_________________/                    \\___\n                        --+------------------------------------------------------> time\n                          |\n\n\n\nNOTA:\nVarias bobinas con el mismo ‘YName’ o ‘RName’ pueden ser mentalmente representadas como un circuito integrado por múltiples entradas y una única salida.\nLas bobinas normal e invertida transfieren directamente el estado de su entrada (normal o invertida) a su salida.\n\nLas bobinas S, R y T retienen el estado de su salida.\nLas bobinas SET y RESET son activadas por nivel, la bobina T es activada por el flanco positivo.\nSi antes de una bobina R, S se inserta la instrucción “OSR: ONE-SHOT RISING” ú “OSF: ONE-SHOT FALLING”, se obtiene un elemento activado por el flanco positivo o por el flanco negativo.\nSi se usan sólo las instrucciones R y S, se obtiene el clásico disparador RS. Si se agrega la instrucción T, se obtiene el más reciente disparador RST. Puede utilizar varias bobinas R…R, o varias entradas S…S con un mismo nombre en un mismo programa. Puede utilizar cualquier combinación de entradas para una bobina de salida física ‘YName’ o para un relé interno ‘RName’.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "DETECCION DE FLANCO POSITIVO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#deteccion-de-flanco-positivo",
    "body": "      ----[_/¨OSR_/¨\\_]----  \n\nNormalmente, la salida de esta instrucción es 0 (OFF, False).\nSi la entrada de la instrucción es 1 (ON, True) en un ciclo de programa y fue 0 (OFF, False) durante el ciclo anterior, entonces la salida es 1 (ON, True) durante un solo ciclo de programa.\nPor lo tanto, genera un pulso positivo con duración de un ciclo de PLC en cada flanco positivo de su señal de entrada. Esta instrucción es útil si desea activar eventos a partir del flanco ascendente de una señal.\n                  OSR     |     ______________________\n                  input   | ___/                      \\_______\n                          |    |\n                  OSR     |    >_< 1 PLC CYCLE\n                  output  | ___/ \\_____________________________\n                          |\n                        --+--------------------------------------> time\n                          |\n"
  },
  {
    "title": "DETECCION DE FLANCO NEGATIVO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#deteccion-de-flanco-negativo",
    "body": "      ----[¨\\_OSF_/¨\\_]----  \n\nNormalmente, la salida de esta instrucción es 0 (OFF, False).\nSi la entrada de la instrucción es 0 (OFF, False) en un ciclo de programa y fue 1 (ON, True) durante el ciclo anterior, entonces la salida es 1 (ON, True) durante un solo ciclo de programa.\nPor lo tanto, genera un pulso positivo con duración de un ciclo de PLC en cada flanco negativo de su señal de entrada. Esta instrucción es útil si desea activar eventos a partir del flanco descendente de una señal.\n                  OSR, OSF|     ______________________\n                  input   | ___/                      \\_______\n                          |                           |\n                  OSF     |                           >_< 1 PLC CYCLE\n                  output  | __________________________/ \\_____\n                          |\n                        --+--------------------------------------> time\n                          |\n\n"
  },
  {
    "title": "DETECCION DE FLANCO NEGATIVO CON SALIDA INVERTIDA",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#deteccion-de-flanco-negativo-con-salida-invertida",
    "body": "      ----[¨\\_OSL¨\\_/¨]----  \n\nNormalmente, la salida de esta instrucción es 1 (ON, True).\nSi la entrada de la instrucción es 0 (OFF, False) en un ciclo de programa y fue 1 (ON, True) durante el ciclo anterior, entonces la salida es 0 (OFF, False) durante un solo ciclo de programa.\nPor lo tanto, genera un pulso negativo con duración de un ciclo de PLC en cada flanco negativo de su señal de entrada. Esta instrucción es útil si desea desactivar eventos a partir del flanco descendente de una señal.\n\n                  OSL     | ___           _______\n                  input   |    \\_________/\n                          |    |\n                          |    > < 1 PLC CYCLE\n                  OSL     | ___   _______________\n                  output  |    \\_/\n                        --+---------------------------> time\n                          |\n\n\n"
  },
  {
    "title": "TEMPORIZADOR A LA CONEXION",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#temporizador-a-la-conexion",
    "body": "           Tname  \n      --[TON 1.000 s]--  \n\nSi la señal en la entrada lógica de la instrucción pasa de 0 (OFF, False) a 1 (ON, True), la señal en la salida permanece en 0 (OFF, False) durante el tiempo T antes de pasar a 1 (ON, True). Cuando  la señal en la entrada lógica de la instrucción pasa de 1 (ON, True) a 0 (OFF, False), la señal en la salida pasa a 0 (OFF, False) inmediatamente. La variable interna del temporizador se restablece a 0 cada vez que la entrada pasa a 0 (OFF, False); la señal en la entrada lógica debe permanecer verdadera durante al menos el tiempo T antes de que la salida resulte verdadera. El tiempo de retardo es configurable.\nLa variable \"Tname\"cuenta desde cero en unidades de tiempo de ciclo del programa. La instrucción TON produce una salida True cuando la variable interna del temporizador es mayor igual o igual al tiempo de retardo configurable. Es posible manipular la variable interna del temporizador por medio de otras instrucciones en el programa, p. ej.por ejemplo con una instrucción MOV.\n\n                   ^  La duración de la señal 1 en la entrada\n                   |  debe ser mayor o igual al parámetro: t(on) >= par\n           TON     |     ____________         ___\n           input   | ___/            \\_______/   \\_____\n                   |    |            |\n                   |    | t          |\n                   |    |<---->|     |\n                   |           |     |\n                   |           v     v\n           TON     |            ______\n           output  | __________/      \\________________\n                 --+-----------------------------------> time,s\n                   |\n\n"
  },
  {
    "title": "TEMPORIZADOR A LA DESCONEXION",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#temporizador-a-la-desconexion",
    "body": "           Tname  \n      --[TOF 1.000 s]--  \n\nSi la señal en la entrada lógica de la instrucción pasa de 0 (OFF, False) a 1 (ON, True), la señal en la salida pasa a 1 (ON, True) inmediatamente y permanece en ese estado mientras se mantiene en 1 la señal de entrada. Cuando  la señal en la entrada lógica de la instrucción pasa de 1 (ON, True) a 0 (OFF, False), la señal en la salida permanece en 1 (ON, True) durante el tiempo T antes de pasar a 0 (OFF, False). La variable interna del temporizador se restablece a 0 cada vez que la entrada pasa a 1 (ON, True). El tiempo de retardo es configurable.\nLa variable \"Tname\"cuenta desde cero en unidades de tiempo de ciclo del programa. La instrucción TON produce una salida True cuando la variable interna del temporizador es mayor igual o igual al tiempo de retardo configurable. Es posible manipular la variable interna del temporizador por medio de otras instrucciones en el programa, p. ej.por ejemplo con una instrucción MOV.\n                   ^  La duración de la señal 1 en la entrada\n                   |  debe ser mayor al tiempo de ciclo del PLC\n           TOF     |        _               ___   ___________\n           input   | ______/ \\_____________/   \\_/           \\___________\n                   |       | |             |                 |\n                   |       | |   t         |                 |    t\n                   |       | |<----->|     |                 |<----->|\n                   |       |         |     |                         |\n                   |       v         v     v                         v\n           TOF     |        _________       _________________________\n           output  | ______/         \\_____/                         \\___\n                 --+-----------------------------------------------------> time,s\n                   |\n\n"
  },
  {
    "title": "TEMPORIZADOR A LA CONEXION RETENTIVO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#temporizador-a-la-conexion-retentivo",
    "body": "           Tname  \n      --[RTO 1.000 s]--  \n\nEsta instrucción hace un seguimiento de cuánto tiempo su entrada de señal lógica ha estado en 1 (ON, True), sumando los tiempos parciales de activación. Si la señal en su entrada lógica ha sido 1 (ON, True) para una sumatoria de tiempos igual o mayor a el parámetro T, entonces la salida pasa a 1 (ON, True). De lo contrario, la salida es 0 (OFF, False).\nLa entrada no requiere estar activada en forma continua por el tiempo T, p. ej.  si el parámetro T = 2 s y la entrada es 1 durante 0,6 s, luego 0 durante 5,0 s, y luego 1 durante 1,4 s, entonces la salida será 1.\nUna vez que que la salida está activada en 1 (ON, True), permanecerá en ese estado incluso después de que la entrada vuelva a 0 (OFF, False), siempre y cuando la señal en la entrada haya sido 1 (ON, True) por un período total mayor al tiempo T. El tiempo de retardo es configurable.\nEste temporizador debe ser restablecido programáticamente, utilizando la instrucción de RESET Timer/Counter --{RES}–.\nLa variable “Tname” cuenta desde cero en unidades de tiempo de ciclo del programa. Es posible manipular la variable interna del temporizador por medio de otras instrucciones en el programa, p. ej.por ejemplo con una instrucción MOV.\n                   ^  La suma de los tiempos de los pulsos en 1 debe ser  \n                   |  mayor o igual al parámetro t: t1 + t2+ .. +tn >= par\n                   |\n           RTO     |     __     _    _________          \n           input   | ___/  \\___/ \\__/         \\________________\n                   |    |  |   | |  |\n                   |    |t1|   | |  |tn                   Trto\n                   |    |<>|  >| |< |<>|                  RESET\n                   |           t2      |                  |\n                   |                   v                  v\n           RTO     |                    __________________\n           output  | __________________/                  \\___\n                 --+-------------------------------------------> time,s\n\n"
  },
  {
    "title": "TEMPORIZADOR A LA DESCONEXION RETENTIVO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#temporizador-a-la-desconexion-retentivo",
    "body": "            Tname  \n        --[RTL 1.000 s]--  \n\nEsta instrucción hace un seguimiento de cuánto tiempo su entrada de señal lógica ha estado en 0, (OFF, False), sumando los tiempos parciales de desactivación.  Si la señal en su entrada lógica ha sido 0 (OFF, False) para una sumatoria de tiempos igual o mayor a el parámetro T, entonces la salida pasa a 1 (ON, True). De lo contrario, la salida es 0 (OFF, False).\nLa entrada no requiere estar desactivada en forma continua por el tiempo T, p. ej.  si el parámetro T = 2 s y la entrada es 0 durante 0,6 s, luego a durante 5,0 s, y luego 0 durante 1,4 s, entonces la salida será 1.\nUna vez que que la salida está activada en 1 (ON, True), permanecerá en ese estado incluso después de que la entrada vuelva a 1 (ON, True), siempre y cuando la señal en la entrada haya sido 0 (OFF, False) por un período total mayor al tiempo T. El tiempo de retardo es configurable.\nEste temporizador debe ser restablecido programáticamente, utilizando la instrucción de RESET Timer/Counter --{RES}–.\nLa variable “Tname” cuenta desde cero en unidades de tiempo de ciclo del programa. Es posible manipular la variable interna del temporizador por medio de otras instrucciones en el programa, p. ej.por ejemplo con una instrucción MOV.\n                   ^  La suma de los tiempos de los pulsos en 0 debe ser\n                   |  mayor o igual al parámetro t: t1 + t2+ .. +tn >= par\n                   |\n           RTL     | ___    ___   __           ________\n           input   |    \\__/   \\_/  \\_________/\n                   |    |  |   | |  |\n                   |    |t1|   | |  |tn                   Trtl\n                   |    |<>|  >|-|< |<>|                  RESET\n                   |           t2      |                  |\n                   |                   v                  v\n           RTL     |                    __________________\n           output  | __________________/                  \\___\n                 --+-------------------------------------------> time,s\n\n"
  },
  {
    "title": "TEMPORIZADOR CICLICO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#temporizador-ciclico",
    "body": "             Tname  \n      --[TCY 500 ms]--  \n\nSi la señal en su entrada lógica es 1 (ON, True), esta instrucción produce en su salida una señal alternada ON->OFF->ON->OFF->…, es decir un ciclo con período T y frecuencia 1/T Hz. Si la señal de entrada 0 (OFF, False), entonces la señal de salida es 0 (OFF, False).\nSi el valor Tname es igual al tiempo de ciclo del programa, el ciclo en la salida del TCY es igual a OSC (período de ciclo del PLC). El tiempo de retardo es configurable.\n                   ^  La duración de la señal 1 en la entrada\n                   |  debe ser mayor al parámetro: t > par\n           TCY     |     ______________________\n           input   | ___/                      \\_______\n                   |    |                      |\n                   |    |  1s    1s    1s      |\n                   |    |<--->|<--->|<--->|    |\n                   |    |     |     |     |    v\n           TCY     |    v   __|   __|   __|   _\n           output  | ______/  \\__/  \\__/  \\__/ \\_______\n                 --+----------------------------------------> time,s\n                   |\n\n"
  },
  {
    "title": "OSCILADOR",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#oscilador",
    "body": "    --[_/¨OSC_/¨\\_/¨\\_]--  \n\nF=1/(2*Tcycle)\nSi la señal en la entrada lógica de la instrucción es 1 (ON, True), produce un ciclo con frecuencia igual al inverso del tiempo de ciclo del PLC * 2.\nSi la señal en la entrada de la instrucción es 0 (OFF, False),la señal de salida siempre es 0 (OFF, False).\n"
  },
  {
    "title": "TEMPORIZADOR DE IMPULSO POSITIVO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#temporizador-de-impulso-positivo",
    "body": "         Tname  \n    --[THI 1.000 s]--  \n\nSi en la entrada lógica de la instrucción la señal tiene un flanco positivo (ascendente) pasando de 0 (OFF, False) a 1 (ON, True), la señal en la salida pasará inmediatamente de 0 (OFF, False) a 1 (ON, True).\nPermanecerá en ese estado durante el tiempo T, luego pasará nuevamente a 0 (OFF, False) y se mantendrá en ese estado sin importar el estado en que se mantiene la entrada (0 - 1), hasta la próxima ocurrencia de un flanco positivo. El tiempo de retardo es configurable.\nInstrucción Activada por Flanco (positivo).\n                   ^  La duración de la señal 1 en la entrada\n                   |  debe ser mayor al tiempo de ciclo del PLC\n           THI     |     _           ________\n           input   | ___/ \\_________/        \\_______\n                   |    |           |\n                   |    |  t        | t\n                   |    |<-->|      |<-->|\n                   |    |    |      |    |\n                   |    v    v      v    v\n           THI     |     ____        ____\n           output  | ___/    \\______/    \\___________\n                 --+------------------------------------> time,s\n                   |\n\n\n"
  },
  {
    "title": "TEMPORIZADOR DE IMPULSO NEGATIVO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#temporizador-de-impulso-negativo",
    "body": "         Tname  \n    --[TLO 1.000 s]--  \n\nSi en la entrada lógica de la instrucción la señal tiene un flanco negativo (descendente) pasando de  1 (ON, True) a 0 (OFF, False), la señal en la salida pasará inmediatamente de 1 (ON, True) a  0 (OFF, False).\nPermanecerá en ese estado durante el tiempo T, luego pasará nuevamente a 1 (ON, True) y se mantendrá en ese estado sin importar el estado en que se mantiene la entrada (0 - 1), hasta la próxima ocurrencia de un flanco negativo. El tiempo de retardo es configurable.\nInstrucción Activada por Flanco (negativo).\n                   ^  La duración de la señal 0 en la entrada\n                   |  debe ser mayor al tiempo de ciclo del PLC\n           TLO     | ___   _________          _______\n           input   |    \\_/         \\________/\n                   |    |           |\n                   |    |  t        |  t\n                   |    |<-->|      |<-->|\n                   |    |    |      |    |\n                   |    v    v      v    v\n           TLO     | ___      ______      ___________\n           output  |    \\____/      \\____/\n                 --+------------------------------------> time,s\n\n"
  },
  {
    "title": "RESET TEMPORIZADOR RETENTIVO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#reset-temporizador-retentivo",
    "body": "     RTOname     RTLname  \n    --{RES}--   --{RES}--  \n\nEsta instrucción restablece la variable interna (pone a a 0) de un temporizador a la conexión retentivo (RTO), o a la desconexión retentivo (RTL).\nLos temporizadores TON y TOF son restablecidos automáticamente cuando la señal en la entrada lógica es 0 ó 1, respectivamente, por lo que la instrucción RES no es necesaria para estos temporizadores.\nLas variables internas de las instrucciones RTO y RTL no son reseteadas automáticamente, por lo que deben restablecerse programáticamente utilizando una instrucción RES. Cuando la entrada  de la instrucción RES es 1 (ON, True), el temporizador se restablece; cuando la entrada es 0 (OFF, False), no se ejecuta ninguna acción.\nRES restablece la variable numérica de las instrucciones de RTO, RTL.\nSi la salida del temporizador retentivo está activada en 1 (ON, True), al restablecerse la variable a 0 mediante la instrucción RES la salida también será inmediatamente restablecida a 0 (OFF, False).\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "RETARDO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#retardo",
    "body": "       n us  \n    --[DELAY]--  \n\nLa instrución RETARDO causa una interrupción por un tiempo equivalente a n microsegundos en la ejecución del programa.\nLa instrucción RETARDO no utiliza ningún temporizador ni contador.\nLas operaciones básicas del microcontrolador NOP() y JMP(dirección actual + 1) son utilizadas para generar la interrupción.\nVer DELAY-us\n"
  },
  {
    "title": "CONVERSOR TIEMPO A RETARDO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#conversor-tiempo-a-retardo",
    "body": "          Tconst  \n    --[T2DELAY 10 us]--  \n\nLa instrucción Conversor Tiempo a Retardo toma la constante de tiempo de ciclo T en ms, la convierte en un valor de retardo específico y guarda el resultado en la variable Tconst para su posterior utilización como parámetro en la instrucción RETARDO.\n"
  },
  {
    "title": "Actualización sobre temporizadores: versiones >= v.4.4.1",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#actualizacion-sobre-temporizadores:-versiones-greater-v.4.4.1",
    "body": ""
  },
  {
    "title": "TON, TOF, THI, TLO, RTO, RTL, TCY",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#ton-tof-thi-tlo-rto-rtl-tcy",
    "body": "          Tname  \n    --[TXX variable]--  \n\nSe puede utilizar una variable general como parámetro de un temporizador.\nUsted debe calcular el valor correcto de la variable de acuerdo al tiempo de ciclo del PLC previamente establecido en Configuraciones > MCU parámetros… > Tiempo Ciclo.\n\nParámetro (ms) = Tplc (ms) * variable.\nP. ej. si Tiempo Ciclo (ms) = 10, para establecer un parámetro de 25 segundos en un temporizador la variable deberá tener un valor igual a 2500 (Tpar = 0,01 ms * 2500).\n\n"
  },
  {
    "title": "CONTADOR ASCENDENTE / DESCENDENTE",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#contador-ascendente-descendente",
    "body": "        Cname            Cname  \n    --[CTU >= 5]--   --[CTD > -5]--  \n\nUna transición de 0 (OFF, False) a 1 (ON, True) (flanco positivo) en la señal de entrada lógica del contador CTU (ascendente) o del contador CTD (descendente) modifica de la variable de conteo, incrementando o decrementando su valor.\nEl estado de la salida del contador es 1 (ON, True) si y sólo si la variable de conteo es igual o mayor que el parámetro en CTU, o mayor en CTD, y 0 (OFF, False) en caso contrario.\nEl estado de la salida puede ser 1 incluso si la señal en la entrada es 0; sólo depende de la comparación entre la variable interna del contador y el parámetro.\nUna vez que en el contador la variable alcanza el valor requerido para la activación de la salida (parámetro), el conteo (ascendente o descendente) no se continúa aunque aparezcan nuevos flancos positivos en la entrada lógica del contador.\nSe pueden programar instrucciones CTU y CTD con el mismo nombre de variable Cname, con el fin de incrementar y decrementar el mismo contador.\nLa instrucción RES (Cname) reinicia un contador (pone a 0 su variable), y tiene prioridad respecto a la entrada de señal lógica, es decir que mientras RES (Cname) esté en 1 (ON, True), el valor de conteo permanecerá en 0 en CTU, o en el valor del parámetro en CTD, y ninguna señal en su entrada lo modificará.\nSe pueden realizar también operaciones aplicables a variables generales (aritméticas, mover, comparación, etc.) sobre la variable de conteo.\n                  |     ___      ________        __       ____            _____\n            Input |____/   \\____/        \\______/  \\_____/    \\__________/\n                  |\n                  |    |        |               |        |               |\n                  |    v        v               v        x               v\n                  |\n          CTU (3) | 0  1        2               3        3       0       1\n                  |                                              _____\n              RES |_____________________________________________/     \\_________\n                  |                              _______________\n              OUT |_____________________________/               \\_______________\n                  |\n                  |    |        |               |         |               |\n                  |    v        v               v         v               x\n                  |\n                  |\n          CTD (4) | 4  3        2               1         0          4    4\n                  |                                                   ________\n              RES |__________________________________________________/        \\__\n                  |                                        __________\n              OUT |_______________________________________/          \\___________\n                  |\n\n\n\nNOTA:\nSi se desea realizar conteo ascendente con una variable que pueda sobrepasar por exceso el parámetro (var > par) y/o conteo descendente y sobrepasar por defecto el parámetro (var < par), ésto deberá implementarse por medio de rutinas generadas con instrucciones matemáticas (suma y resta), de evaluación de flanco, y de comparación contra el parámetro fijo o variable. P. ej.:\n\n  ||; Increasing variable = Count Up\n  ||       Xinc                        { ADD var :=}\n  ||-------] [------[_/¨OSR_/¨\\_]------{ var + 1   }--\n  ||  \n  ||; Decreasing variable = Count Down\n  ||       Xdec                        { SUB var :=}\n  ||-------] [------[_/¨OSR_/¨\\_]------{ var - 1   }--\n  ||\n  ||; Evaluating the math counter output (fixed/variable parameter)\n  ||       [ var  ]                           Rreached\n  ||-------[>= par]------------------------------( )--\n  ||\n  ||; Resetting the math counter\n  ||       Xres                         { var  :=  }\n  ||-------] [--------------------------{ 0     MOV}--\n\n"
  },
  {
    "title": "RESET CONTADOR ASCENDENTE / DESCENDENTE",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#reset-contador-ascendente-descendente",
    "body": "     CTUname     CTDname  \n    --{RES}--   --{RES}--  \n\nEsta instrucción restablece al valor 0 la variable interna en un contador ascendente (CTU), y restablece al valor inicial la variable interna en un contador descendente (CTD).\nLas variables internas de las instrucciones CTU y CTD no son reseteadas automáticamente, por lo que deben restablecerse programáticamente utilizando una instrucción RES.\nCuando la entrada  de la instrucción RES es 1 (ON, True), el contador se restablece; cuando la entrada es 0 (OFF, False), no se ejecuta ninguna acción.\nRES restablece sólo la variable numérica de las instrucciones de CTU / CTD, no sus salidas. El estado de las salidas sólo depende de la operación de comparación entre la variable y el parámetro.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "CONTADOR CIRCULAR ASCENDENTE / DESCENDENTE",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#contador-circular-ascendente-descendente",
    "body": "        Cname           Cname  \n    --[CTC 0:7]--   --[CTR 5:0]--  \n\nUn contador circular funciona como un contador normal ascendente o descendente, excepto que después de alcanzar su límite (variable igual al parámetro), al leer el primer flanco ascendente en su entrada, restablece automáticamente su variable a 0 (en CTC) o al valor máximo (en CTD).\nAl ocurrir este evento, su salida se activa durante un sólo ciclo de escaneo de programa (pulso positivo).\nPor ejemplo, el contador CTC mostrado en primer lugar contaría 0, 1, 2, 4, 5, 6, 7, 0, 1, 2,…   Esto es útil en combinación con operaciones de comparación ejecutadas sobre la variable “Cname”; usted puede utilizar ésto como un secuenciador para activar o desactivar otras instrucciones o rutinas del programa.\nCTR es un contador circular reverso, el contador CTR mostrado en segundo lugar contaría 5, 4, 3, 2, 1, 0, 5, 4, 3,…\n                  |     ___      ________        __       ____             ____\n            Input |____/   \\____/        \\______/  \\_____/    \\___________/\n                  |\n                  |    |        |               |        |                |\n                  |    v        v               v                         v\n                  |\n           CTC(3) | 0  1        2               3         0               1\n                  |                             >_< 1 PLC CYCLE\n              OUT |_____________________________/ \\_____________________________\n                  |\n                  |    |        |               |         |                |\n                  |    v        v               v         v                v\n                  |\n                  |\n           CTR(4) | 4  3        2               1         0                4\n                  |                                       >_< 1 PLC CYCLE  \n               OUT|_______________________________________/ \\___________________\n                  |\n\n\nLa instrucción RES (Cname) reinicia un contador (pone a 0 su variable), y tiene prioridad respecto a la entrada de señal lógica, es decir que mientras RES (Cname) esté en 1 (ON, True), el valor de conteo permanecerá en 0 en CTC, o en el valor del parámetro en CTR, y ninguna señal en su entrada lo modificará.\nSe pueden realizar también operaciones aplicables a variables generales (aritméticas, mover, etc.) sobre la variable de conteo.\n"
  },
  {
    "title": "Actualización sobre contadores: versiones >= v.4.4.1",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#actualizacion-sobre-contadores:-versiones-greater-v.4.4.1",
    "body": ""
  },
  {
    "title": "CTU, CTD, CTC, CTR",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#ctu-ctd-ctc-ctr",
    "body": "Se puede utilizar una variable general como parámetro de un contador.\n"
  },
  {
    "title": "CONVERSOR TIEMPO A CONTADOR",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#conversor-tiempo-a-contador",
    "body": "         Tconst  \n    --[T2CNT 10 ms]--  \n\nLa instrucción  Conversor Tiempo a Contador toma la constante de tiempo de ciclo T en ms, la convierte en un valor de unidades de temporización y guarda el resultado en la variable Tconst para su posterior utilización como parámetro en contadores.\nVer TIME-to-COUNTER-converter"
  },
  {
    "title": "Actualización sobre contadores: versiones >= v.4.4.0",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#actualizacion-sobre-contadores:-versiones-greater-v.4.4.0",
    "body": "Los contadores CTU, CTD, CTC y CTR en las versiones >= v.4.4.0 admiten más opciones de configuración:\n\nSe puede utilizar una variable general como parámetro de un contador.\nPermiten establecer un valor de inicialización START establecido por el usuario y distinto de 0 (valor por defecto), es decir que al efectuar la instrucción RES sobre un contador, la variable contendrá el valor específico START.\nEn CTU y CTC (contadores ascendentes), START deberá ser menor que el parámetro máximo (START < MAX); en CTD y CTR (contadores descendentes), START deberá ser mayor que el parámetro mínimo (START > MIN).\nTambién permiten establecer si la señal a evaluar en la entrada de conteo será dinámica por flanco positivo (/) o flanco negativo (\\), o será estática normal (-) o invertida (o).\nLos contadores circulares CTC y CTD ya no requieren ser programados en el extremo derecho del escalón (rung), pudiendo utilizarse como operaciones intermedias. P. ej. ésto es útil si envía la señal de salida del contador a un relé interno (marca) Rname y utiliza sus contactos Rname como condición de entrada para otras instrucciones.\n\n   ||                               ||\n   ||  X1          CTU1:0      Y1   ||\n   ||--] [---+---/[CTU>=10]----( )--|| '/' Entrada dinámica, activa en transición 0 a 1.\n   ||        |                      ||\n   ||        |     CTU2:0      Y2   ||\n   ||        +---\\[CTU>=10]----( )--|| '\\' Entrada dinámica, activa en transición 1 a 0.\n   ||        |                      ||\n   ||        |     CTU3:0      Y3   ||\n   ||        +----[CTU>=10]----( )--|| '-' Entrada estática directa, activa en 1.\n   ||        |                      ||\n   ||        |     CTU4:0      Y4   ||\n   ||        +---o[CTU>=10]----( )--|| 'o'  Entrada estática inversa, activa en 0.\n   ||                               ||      Negación en la entrada lógica.\n   ||                               ||      Nivel 0 externo produce nivel 1 interno.\n   ||                               ||\n\n\n\nNOTA:\nTodos los contadores en versiones anteriores a v.4.4.0 tienen entrada dinámica por flanco positivo. La entrada por defecto --/{CTX}-- es compatible con dichas versiones.\n\n\nConsejo:\nSi para la aplicación resultan necesarios contadores bidireccionales con posibilidad de que la variable de conteo vaya más allá de los valores de parámetros (por exceso o por defecto), este requerimiento puede implementarse en el programa por medio de instrucciones aritméticas de suma y resta sobre una misma variable, en conjunto con operaciones de comparación.\n\nPuede utilizar la instrucción de evaluación de flanco positivo -{OSR}- para emular los contadores de versiones anteriores a v.4.4.0 al realizar esta programación.\nPuede implementar la operación -{MOV 0, var}- en forma equivalente a una operación -{RES Cnt}-"
  },
  {
    "title": "CONVERTIDOR ANALOGICO/DIGITAL",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#convertidor-analogicodigital",
    "body": "        Aname  \n    --{READ ADC}--  \n\nLDmicro puede generar código para usar los conversores Analógico/Digital incorporados en ciertos modelos de microcontroladores.\nSi la señal en la entrada lógica a esta instrucción es 1 (ON, True), entonces se adquiere una sola muestra del conversor A/D, y su valor es almacenado en la variable “Aname”.\nSi la señal en la entrada lógica es 0 (OFF, False), entonces la variable “Aname” no tendrá cambios.\nPara todos los dispositivos actualmente soportados, una señal de 0 voltios corresponde a una lectura ADC de 0, y una señal igual a Vdd (la tensión de alimentación) corresponde a una lectura ADC de 1023.\nSi está utilizando un microcontrolador AVR, conecte AREF a AVcc, y AVcc a Vcc con un circuito de filtrado LC (ver hoja de datos del microcontrolador).\n\nNOTA:  A partir de la versión v.4.4.0, puede establecer una tensión de referencia diferente de Vdd mediante el parámetro REFS de la instrucción READ ADC.\n\nEl parámetro REFS por defecto 0 es compatible con versiones anteriores, y utiliza Vdd como tensión de referencia para la conversión A/D.\nPuede seleccionar otras fuentes de referencia en función del modelo de microcontrolador.\nVer ADC-Voltage-Reference\nEsta variable puede ser manipulada con las mismas operaciones que se pueden efectuar sobre variables generales (comparaciones, aritméticas, y así sucesivamente).\nPuede utilizar operaciones matemáticas para convertirla a unidades más convenientes (unidades de ingeniería), pero recuerde que estará utilizando operaciones aritméticas sobre enteros.\nAsigne un pin a la variable “Aname” de la misma manera que asigna un pin a una entrada o salida digital, haciendo doble click en su nombre en la lista de objetos en la parte inferior de la ventana.\nEn general no todos los pines estarán disponibles para uso con el convertidor A/D. El software no le permitirá asignar pines que no diponen de ADC a una entrada analógica.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung)."
  },
  {
    "title": "PWM: CONFIGURAR CICLO DE SERVICIO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#pwm:-configurar-ciclo-de-servicio",
    "body": "       duty_cycle  \n    --{PWM 10 kHz}--  \n\nLDmicro puede generar código para usar el periférico PWM incorporado en ciertos microcontroladores.\nSi la condición de entrada a esta instrucción es 1 (ON, True), entonces la relación “marca” (1, ON) / “espacio” (0, OFF) en la modulación de ancho de pulso se ajusta al valor de la variable duty_cycle (ciclo de servicio).\nEl ciclo de servicio debe ser un número entre 0 y 100 (porcentaje); 0 corresponde a siempre bajo (0, OFF) y 100 corresponde a siempre alto (1, ON). Si está familiarizado con el funcionamiento del periférico PWM, note que ésto significa que LDmicro escala automáticamente la variable del ciclo de trabajo a la frecuencia PWM en base al porcentaje establecido.\nPuede especificar la frecuencia base del PWM expresada en Hz. La frecuencia base que se especifique puede no ser exactamente alcanzable, dependiendo de cómo se divide en relación a la frecuencia de trabajo del microcontrolador (interna, RC, cristal). LDmicro seleccionará la frecuencia base más cercana posible; si el error es grande entonces lo advertirá en un cuadro de diálogo. Frecuencias base muy altas pueden sacrificar la resolución de la salida PWM.\n\nNOTA:\nEl código generado por la lógica Ladder utiliza un temporizador interno para medir el tiempo de ciclo (ejecución) del programa. Ésto significa que la instrucción modulación de ancho de pulso PWM sólo está disponible para microcontroladores que disponen al menos de dos temporizadores internos (Timer0, Timer1). PWM utiliza el pin CCP2 (no CCP1) en microcontroladores PIC16, y el pin OC1B (no OC1A) en AVR.\n\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung)."
  },
  {
    "title": "Actualización sobre PWM: versiones >= v.4.0.0",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#actualizacion-sobre-pwm:-versiones-greater-v.4.0.0",
    "body": "LDmicro >= V4.x.x permite diferentes resoluciones en la variable duty_cycle:\n\n0-100 - 6,7 bits\n0-255 - 8 bits\n0-511 - 9 bits\n0-1023 - 10 bits\nTambién permite utilizar todos los PWM disponibles en el hardware.\nVer LDmicro-PWM\n\nATENCION: si se requiere cambiar la frecuencia base del PWM (no su ciclo de servicio) durante la ejecución del programa en el microcontrolador, utilice la instrucción RESET PWM siguiente."
  },
  {
    "title": "RESET PWM",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#reset-pwm",
    "body": "       PWM  \n    --{RES}--  \n\nSi la señal en la entrada lógica de la instrucción 1 (ON, True), esta instrucción inhabilita la modulación de ancho de pulso PWM y establece permanentemente la salida de pulsos en nivel bajo (0, OFF).\nPermite configurar otra frecuencia base para la modulación de ancho de pulso PWM establecida mediante una instrucción SET PWM DUTY CYCLE previa; esta nueva configuración sólo se puede implementar mientras el PWM está deshabilitado mediante la ejecución de la instrucción RESET PWM.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "VARIABLE PERSISTENTE",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#variable-persistente",
    "body": "      saved_var  \n    --{PERSIST}--  \n\nCuando la condición de entrada de esta instrucción es 1 (ON, True), la variable especificada es automáticamente guardada (escrita) en la memoria EEPROM. Ésto significa que su valor se mantendrá incluso cuando el microcontrolador no está energizado (sin alimentación).\nNo hay necesidad de guardar explícitamente la variable en EEPROM; ésto sucederá automáticamente siempre que cambie su valor.\nDespués de la energización (alimentación) del microcontrolador, el valor guardado se carga automáticamente desde la EEPROM en la variable.\n\nNOTA: Si una variable que cambia con frecuencia se hace persistente, la memoria EEPROM en el microcontrolador puede degradarse muy rápidamente, dado que sólo soporta un número limitado de escrituras (~100.000).\n\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\nVer MAKE-PERSISTENT-operation\n"
  },
  {
    "title": "MOVER VARIABLE",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#mover-variable",
    "body": "    {destvar :=  }     {Tret :=  }  \n    --{ 123 MOV}--   --{srcvar MOV}--  \n\nSi la señal en la entrada lógica de la instrucción 1 (ON, True), a la variable destino le será asignado un valor igual a la variable origen o de la constante. Cuando la entrada a esta instrucción es 0 (OFF, False), la variable destino permanece sin cambios.\nCon la instrucción MOV se puede asignar un valor a cualquier tipo de variable destino; ésto incluye variables de temporizadores y contadores, que pueden ser distinguidas en el esquema Ladder por comenzar con las letras ‘T’ o ‘C’. Por ejemplo, una instrucción MOV 0 a “Tret” es equivalente a una instrucción Reset -{RES}- para ese temporizador.\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la variable “dest” no modifica su valor.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "OPERACIONES ARITMETICAS CON VARIABLES",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#operaciones-aritmeticas-con-variables",
    "body": "      {ADD kay   :=}       {SUB Ccnt  :=}  \n    --{ 'a' + 10   }--   --{ Ccnt - 10  }--  \n\n      {MUL dest  :=}       {DIV dv    :=}  \n    --{ var * -990 }--   --{ dv / -10000}--  \n\nSi la señal en la entrada lógica en cada una de estas instrucciones es 1 (ON, True), la variable de destino será igual a la operación especificada entre los operandos.\nLos operandos pueden ser variables (incluyendo variables de temporizador y contador) o constantes. Estas instrucciones utilizan variables con signo y sólo admiten números enteros.\nUna operación aritmética admite tener como variable destino la misma variable de origen.\nRecuerde que el resultado se evalúa en cada ciclo cuando la condición de entrada es 1 (ON, True).\nSi está incrementando o decrementando una variable (es decir, si la variable de destino es también uno de los operandos), entonces usted probablemente no querrá que suceda ésto; típicamente deberá utilizar una instrucción de detección de flanco previa para que la instrucción se evalúe sólo al detectarse un flanco ascendente o descendente en su entrada lógica.\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la variable “dest” no modifica su valor.\nNOTA IMPORTANTE:\nLa instrucción DIV (dividir) trunca el valor del resultado, es decir que descarta los decimales; 7/3 = 2. Recuerde que las variables siempre son números enteros con signo.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "OPERACION MODULO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#operacion-modulo",
    "body": "     {MOD dest:=}  \n    --{src % 2}--  \n\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), la variable de destino será igual al resto (sobrante, número entero positivo) de la división del Operando1 por el Operando2.\nEjemplo: 7 % 3 = 1\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la variable “dest” no modifica su valor.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\nVer Modulo_operation\n"
  },
  {
    "title": "NEGATIVO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#negativo",
    "body": "      {NEG dest:=}  \n    --{  -    src}--  \n\nSi la señal en la entrada lógica de la instrucción es 1 (ON, True), esta instrucción invierte el signo de una variable (entero).\nNegativo (NEG a:= -a)- es el equivalente optimizado de -{SUB a:= 0 - a}-\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la variable “dest” no modifica su valor.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "OPERACIONES DE COMPARACION",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#operaciones-de-comparacion",
    "body": "      [var ==]       [var >]       [1 >=]  \n    --[ var2 ]--   --[ 1   ]--   --[ Ton]--  \n\n      [var !=]       [-4 <   ]       [1 <=]  \n    --[ var2 ]--   --[ vartwo]--   --[ Cup ]--  \n\nEsta instrucción se puede utilizar para comparar una variable con otra variable, o comparar una variable con una constante con signo.\nSi la señal en la entrada lógica de la instrucción es 1 (ON, True), entonces la salida es 1 (ON, True) si y solamente si el resultado de la comparación es verdadero.\nLas operaciones de comparación disponibles son: igual que, mayor que, mayor que o igual a, no es igual a, menor que, menorque o igual a.\nSi la entrada de señal de la instrucción es 0 (OFF, False), la operación de comparación no se efectúa y la salida es 0 (OFF, False).\n"
  },
  {
    "title": "OPERACIONES LOGICAS BIT A BIT",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#operaciones-logicas-bit-a-bit",
    "body": "      {AND  var1 :=}       {OR   Ccnt :=}  \n    --{var2 & var3 }--   --{ Ccnt | 0o07}--  \n  \n      {XOR  dest :=}       {NOT  dv :=  }  \n    --{ var ^ 0xAA }--   --{ ~0b11001100}--  \n\nSi la señal en la entrada lógica de la instrucción es 1 (ON, True), la variable de destino será igual a la operación lógica entre los bits correspondientes (idéntica posición) de los operandos.\nLos operandos pueden ser variables (incluyendo variables de temporizador o contador) y/o constantes.\nRecuerde que el resultado se evalúa en cada ciclo de programa mientras la condición de entrada sea verdadera.\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la variable “dest” no modifica su valor.\nVer Bitwise_operation\n"
  },
  {
    "title": "ACTIVAR / DESACTIVAR UN BIT",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#activar-desactivar-un-bit",
    "body": "          {var}              {var}  \n    --{SetBit bit}--   --{ClrBit bit}--  \n\n--{SetBit var, bit}-- activa (pone a 1) el bit número “bit” de la variable “var”.\n--{ClrBit var, bit}-- desactiva (pone a 0) el bit número “bit” de la variable “var”.\nEn la instrucción, “bit” significa número de bit, no máscara de bit.\nPor ejemplo, para establecer (poner a 1) el bit número 4 en la variable “var”:\n    Bit número:  76543210  \n    variable:    xxx1xxxx  \n\nSe debe programar\n         {var}  \n    --{SetBit 4}--   \n\nésto es equivalente a programar\n      {OR var  :=}\n    --{var | 0x10}--\n\nNO se deben programar instrucciones SetBit ni ClrBit utilizando hexadecimales:\n          {var}  \n    --{SetBit 0x10}-  NO ADMITIDO!!!  \n\n"
  },
  {
    "title": "COMPROBAR EL ESTADO DE UN BIT",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#comprobar-el-estado-de-un-bit",
    "body": "           [var]                [var]  \n    --[IfBitSet bit]--   --[IfBitClr bit]--  \n\nEstas instrucciones se pueden usar para verificar el estado (0 = CLEAR; 1 = SET) de un bit determinado en una variable.\nImportante: “bit” significa número del bit, no máscara de bit.\nSi la señal en entrada lógica de la instrucción es 1 (ON, True), la salida es 1 (ON, True) si y sólo si el resultado de la comprobación es verdadero.\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la operación de comparación no se efectúa y la salida es 0 (OFF, False).\nLa operación --{IfBitSet var, 0}-- es equivalente a la expresión “si la variable es impar, entonces…”.\nLa operación --{IfBitClr var, 0}-- es equivalente a la expresión “si la variable es par, entonces…”.\n\nINSTRUCCIONES DE DESPLAZAMIENTO DE BITS: SHL, SHR, SR0, ROL, ROR\nSi la señal en la entrada lógica de la instrucción es 1 (ON, True), los bits de la variable origen son desplazados en la dirección correspondiente y asignados a la variable destino. La variable destino puede ser la misma que la variable origen.\nLos operandos que indican la cantidad de posiciones del desplazamiento pueden ser variables (incluyendo variables de temporizador o contador) o constantes.\nRecuerde que el resultado se evalúa en cada ciclo de programa mientras la condición de entrada sea verdadera.\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la variable “dest” no modifica su valor.\n\nNota referida a los gráficos de las operaciones:\nMSB = Most Significant Bit (bit más significativo o de mayor peso)\nLSB = Least Significant Bit (bit menos significativo o de menor peso)\n\nVer Circular shift\nVer Arithmetic_shift\n"
  },
  {
    "title": "DESPLAZAMIENTO ARITMETICO A LA IZQUIERDA / DERECHA",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#desplazamiento-aritmetico-a-la-izquierda-derecha",
    "body": "     {SHL  var1 :=}     {SHR   cnt :=}  \n    --{var2 << 2 }--   --{cnt >>  1 }--  \n\nSHL - desplazamiento aritmético a la izquierda\n        MSB                    LSB  \n            MSB-1            1  0  \n    C <- x <- x <- .... <- x <- x <- 0  \n\nSHR - desplazamiento aritmético a la derecha\n   MSB                         LSB  \n        MSB-1              1    0  \n    x--> x -> x -> .... -> x -> x -> C  \n     \\<</   \n\n"
  },
  {
    "title": "DESPLAZAMIENTO LOGICO A LA DERECHA",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#desplazamiento-logico-a-la-derecha",
    "body": "      {SR0  dest :=}  \n    --{var  sr0  3 }--  \n\nSR0 - desplazamiento lógico a la derecha\n        MSB                    LSB   \n             MSB-1         1    0  \n    0 -> x -> x -> .... -> x -> x -> C  \n\n"
  },
  {
    "title": "DESPLAZAMIENTO LOGICO A LA IZQUIERDA",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#desplazamiento-logico-a-la-izquierda",
    "body": "El desplazamiento lógico a la izquierda es equivalente a SHL, desplazamiento aritmético a la izquierda.\nVer Logical shift\n"
  },
  {
    "title": "DESPLAZAMIENTO CIRCULAR A LA IZQUIERDA / DERECHA",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#desplazamiento-circular-a-la-izquierda-derecha",
    "body": "     {ROL  dest :=}    {ROR    dv :=}  \n    --{var rol 4}--   --{var ror 4}--  \n\nROL - desplazamiento circular a la izquierda\n        MSB                    LSB  \n             MSB-1         1    0  \n    C <- x <- x <- .... <- x <- x  \n          \\>------------------>/  \n\nROR - desplazamiento circular a la derecha\n   MSB                    LSB  \n        MSB-1        1    0  \n    x -> x -> .... -> x -> x -> C  \n     \\<------------------</  \n\n"
  },
  {
    "title": "INVERTIR ORDEN DE BITS",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#invertir-orden-de-bits",
    "body": "         {dest:=}  \n    --{OPPOSITE src}--  \n\nEsta instrucción invierte el orden de todos los bits de una variable.\nSi la señal en la entrada lógica de la instrucción es 1 (ON, True), mueve el bit más significativo MBS a la posición del bit menos significativo LSB y viceversa, y así sucesivamente con los demás bits.\n    MSB      bits       LSB\n    n n-1 n-2 ... 2  1  0\n    ^  ^   ^      ^  ^  ^\n    |  |   |      |  |  |\n    |  |   +------+  |  |\n    |  +-------------+  |\n    +-------------------+\n\n\nIntercambios en los bits:\n\nMSB <-> 0\nMSB-1 <-> 1\nMSB-2 <-> 2\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la variable “dest” no modifica su valor.\n"
  },
  {
    "title": "INTERCAMBIO DE BYTES Y CUARTETOS",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#intercambio-de-bytes-y-cuartetos",
    "body": "       {dest:=}  \n    --{SWAP src}--  \n\nSi la señal en la entrada lógica de la instrucción es 1 (ON, True), esta instrucción intercambia bytes y cuartetos (nibbles, tétradas) de una variable.\nEn función del tamaño en bytes de la variable (alcance, span), el resultado es diferente:\n1 byte: intercambia los cuartetos dentro de un int8 (BYTE), p. ej. 0x73 -> 0x37\n    MSB       bits       LSB\n    7  6  5  4  3  2  1  0\n    \\________/  \\________/\n         ^           ^\n         |           |\n         +-----------+\n\n\nIntercambios en los bits:\n\n7 <-> 3\n6 <-> 2\n5 <-> 1\n4 <-> 0\n2 bytes: intercambia los bytes dentro de un int16 (WORD), p. ej. 0x7733 -> 0x3377\n    MSB                  bits                   LSB\n    15 14 13 12 11 10 9 8  7  6  5  4  3  2  1  0\n    \\___________________/  \\____________________/\n                    ^           ^\n                    |           |\n                    +-----------+\n\n\nIntercambios en los bits:\n15 <-> 7\n14 <-> 6\n…\n9 <-> 1\n8 <-> 0\n\n3 bytes: intercambia los cuartetos del byte central, y también ambos bytes de los extremos de un int24, p. ej,. 0x775A33 -> 0x33A577\n    MSB                             bits                          LSB\n     23 22 21 20 19 18 17 16 15 14 13 12 11 10  9  8 7 6 5 4 3 2 1 0\n     \\_____________________/ \\_________/ \\_________/ \\_____________/\n                    ^             ^           ^             ^\n                    |             |           |             |\n                    |             +-----------+             |\n                    +---------------------------------------+\n\n\nIntercambios en los bits:\n15 <-> 7\n23 <->  7\n…\n16 <->  0\n15 <-> 11\n…\n12 <->  8\n\n4 bytes: intercambia los bytes de los extremos (3 y 0) y también los bytes centrales (2 y 1) en un int32 (DWORD), p. ej. 0x7755AA33 -> 0x33AA5577\n\n  MSB                                          bits                                  LSB\n  31 30 29 28 27 26 25 24 23 22 21 20 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 0\n  \\_____________________/ \\_____________________/ \\___________________/ \\_____________/\n                 ^                        ^           ^                       ^\n                 |                        |           |                       |\n                 |                        +-----------+                       |\n                 +------------------------------------------------------------+\n\n\nIntercambios en los bits:\n15 <-> 7\n31 <->  7\n…\n24 <->  0\n23 <-> 15\n…\n16 <->  8\n\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la variable “dest” no modifica su valor.\n"
  },
  {
    "title": "REGISTRO DE DESPLAZAMIENTO CON VARIABLES",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#registro-de-desplazamiento-con-variables",
    "body": "     {SHIFT REG}  \n    --{var0..3}--  \n\nUn registro de desplazamiento con variables está asociado con un conjunto de variables “var (índice)”.\nLa entrada de datos al registro de desplazamiento es la variable con índice 0 (var0).\nEn cada flanco positivo (ascendente) en la entrada lógica de la instrucción, se desplaza el valor de la variable en cada registro i a la variable en el registro a su derecha (i + 1).\nEl valor de la variable en el registro de mayor índice es descartado.\nPor ejemplo, el registro de desplazamiento {SHIFT REG} --{reg0…3}–se asocia con las variables reg0, reg1, reg2 y reg3.\nÉsto significa que al activarse la instrucción, se asigna reg3: = reg2, luego reg2: = reg1 y finalmente reg1: = reg0.\nreg0 se mantiene inalterado al ejecutar la instrucción; luego de ejecutarla se puede mover un nuevo valor a la variable de entrada (reg0), el que posteriormente será desplazado a las variables subsecuentes del registro en cada nueva operación de desplazamiento.\n\nNOTA: un Registro de Desplazamiento con gran número de variables puede consumir fácilmente una gran cantidad de memoria.\n\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "BUSQUEDA EN TABLA",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#busqueda-en-tabla",
    "body": "      {dest := }  \n    --{ LUT[i] }--  \n\nUna tabla de consulta es un conjunto ordenado de n pares de valores i <-> value.\nSi la señal en entrada lógica de la instrucción es 1 (ON, True), la variable “dest” tendrá un valor igual a la entrada correspondiente al índice i en la tabla de búsqueda.\nEl índice comienza desde cero, de modo que el índice i debe ser un número entero entre 0 y n - 1.\nEl comportamiento de esta instrucción es indefinido si el índice está fuera de este rango.\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), la variable “dest” no modifica su valor.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "LINEARIZACION POR TRAMOS",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#linearizacion-por-tramos",
    "body": "        {yvar := }  \n    --{ PWL[xvar] }--  \n\nEsta instrucción permite aproximar una función complicada o curva.\nPor ejemplo, podría ser útil si está intentando aplicar una curva de calibración para convertir una salida no lineal de un sensor a unidades más convenientes.\nSuponga que está intentando aproximar una función que convierte una variable de entrada entera, x, a una variable de salida entera, y desea conocer el valor se la función en diferentes puntos.\nPor ejemplo, usted puede saber que la salida de:\nf(0)   = 2  \nf(5)   = 10  \nf(10)  = 50  \nf(100) = 100  \n\nÉsto significa que los puntos forman una curva:\n(x0, y0)   = (  0,   2)  \n(x1, y1)   = (  5,  10)  \n(x2, y2)   = ( 10,  50)  \n(x3, y3)   = (100, 100)  \n\nUsted puede introducir esos cuatro puntos en una tabla asociada con la instrucción Linearización por Tramos.\nLa instrucción leerá el valor de la variable “xvar” y calculará el valor de la variable “yvar” de  modo tal que la curva aproximada mediante tramos lineales pase por todos los puntos de referencia; por ejemplo, si establece xvar = 10, entonces la instrucción establecerá yvar = 50.\nSi a la instrucción se le ingresa un valor de xvar que está entre dos de los valores de x para los cuales se le ha fijado puntos en la tabla asociada, entonces la instrucción establecerá yvar de modo que (xvar, yvar) se encuentre en la línea recta que une esos dos puntos en la tabla.\nEn el ejemplo, xvar = 55 dará una salida de yvar = 75: los dos puntos de la tabla son (10, 50) y (100, 100). 55 está a medio camino entre 10 y 100, y 75 está a medio camino entre 50 y 100, por lo que (55, 75) se encuentra sobre la línea que une esos dos puntos.\nLos puntos deben ser especificados en orden ascendente por sus coordenadas x.\nLos valores de los pares de puntos x-y ingresados eventualmente podrían impedir realizar las operaciones aritméticas necesarias para ciertas tablas de consulta usando variables enteras de 16 bits; si este es el caso, entonces LDmicro mostrará una advertencia.\nPor ejemplo, esta tabla de búsqueda producirá un error:\n(x0, y0)    = (  0,   0)  \n(x1, y1)    = (300, 300)  \n\nPuede corregir este tipo de errores haciendo más pequeña la distancia entre puntos de referencia.\nPor ejemplo, esta tabla es equivalente a la de arriba, y no produce un error:\n(x0, y0)    = (  0,   0)  \n(x1, y1)    = (150, 150)  \n(x2, y2)    = (300, 300)  \n\nCasi nunca será necesario utilizar más de cinco o seis puntos. Añadir más puntos hace que su código resulte más grande y más lento de ejecutar.\nSi se pasa un valor a xvar mayor que la mayor coordenada x, o menor que la menor coordenada x, establecidas en la tabla de referencia, el comportamiento de la instrucción resulta indefinido.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "CIRCUITO CERRADO, CIRCUITO ABIERTO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#circuito-cerrado-circuito-abierto",
    "body": "    --+---+--    --+   +--  \n\nLa condición de salida de un circuito cerrado es siempre igual a su condición de entrada. La condición de salida de un circuito abierto es siempre 0 (OFF, False). Éstas instrucciones son útiles para realizar depuración en el programa de usuario.\n"
  },
  {
    "title": "RELE DE CONTROL MAESTRO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#rele-de-control-maestro",
    "body": "    --{MASTER RLY}--  \n\nDe forma predeterminada, la condición de inicio de cada escalón (rung) es verdadera.\nSi una instrucción de Relé de Control Maestro se ejecuta con una señal de 0 (OFF, False) provista por una instrucción previa en su entrada lógica, entonces la condición de inicio para todos los escalones (rungs) subsiguientes será falsa.\nÉsto persistirá hasta que se alcance la siguiente instrucción de Relé de Control Maestro (con independencia de la condición de entrada de dicha instrucción), desactivando por lo tanto la ejecución de toda la lógica programada en los escalones (rungs) intermedios entre ambas instrucciones MASTER RLY.\nPor consiguiente, esta instrucción debe utilizarse por pares: la primera para iniciar la sección de programa que eventualmente requiera ser deshabilitada en función de determinadas condiciones, y la segunda para finalizar dicha sección.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "GOTO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#goto",
    "body": "         ?  \n    --{GOTO}--  \n\nLa instrucción GOTO() permite realizar saltos en el orden de ejecución del programa, en función de la salida de otra instrucción previa que provea la señal a su entrada lógica.\nLa instrucción GOTO() puede ser utilizada de dos modos: a) con un argumento numérico “n”, b) con un argumento textual “name”.\na) La instrucción GOTO(n), en la que “n” es un número entero, causa un salto en la ejecución del programa al escalón (rung) identificado con el número n:\n\nSi n es igual a 0 (n==0) la ejecución del programa salta al comienzo del ciclo de PLC: se comprueba el temporizador de ciclo (PLC timer), se restablece el temporizador de control (CLRWDT), y se comienza a ejecutar el programa de usuario desde su primera instrucción.\nSi n es menor que 0 (n<0) la ejecución del programa salta a la dirección 0 de la memoria de programa: se produce un restablecimiento por software (SOFT RESET) del microcontrolador.\nSi n es mayor que el número de escalones en el esquema Ladder (n>max_rung), la ejecución del programa salta todas las instrucciones subsiguientes y recomienza el ciclo de PLC.\n\nb) La instrucción GOTO(name), en la que “name” es el nombre asignado a la etiqueta en una instruccion LABEL(name), causa un salto en la ejecución del programa al escalón (rung) en el que se ha programado la correspondiente instrucción destino LABEL(name).\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "LABEL",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#label",
    "body": "         ?  \n    --{LABEL}--  \n\nLa instrucción LABEL(name) identifica el punto de destino para el salto en la ejecución del programa generado por una instrucción GOTO(name).\nLos nombres asignados a cada una de las instrucciones LABEL(name) y a su correspondiente llamada GOTO(name) deben ser únicos en cada programa, y distinguen mayúsculas y minúsculas.\n"
  },
  {
    "title": "SUBPROG, ENDSUB, GOSUB, RETURN",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#subprog-endsub-gosub-return",
    "body": "Este conjunto de instrucciones permite gestionar llamadas a subprogramas (subrutinas) que se pueden procesar una o más veces en el transcurso de un mismo ciclo de PLC.\nLas instrucciones que se procesarán durante la ejecución de un subprograma (subrutina) deberán ser programadas en escalones (rungs) ubicados entre el correspondiente par de instrucciones SUBPROG(name) y ENDSUB(name).\nLuego de finalizar el procesamiento de un subprograma SUBPROG(name), ya sea por haber alcanzado la instrucción ENDSUB(name) o por haber alcanzado una instrucción RETURN, la ejecución del programa principal continuará por la instrucción subsiguiente a la instrucción GOSUB(name) que ha iniciado la ejecución de la correspondiente instrucción SUBPROG(name).\n          ?  \n    --{SUBPROG}--  \n\nLa instrucción SUBPROG(name) señaliza el inicio del subprograma (subrutina) que se procesará al ejecutarse la correspondiente instrucción de llamada GOSUB(name), y obligatoriamente debe ser finalizada con una instrucción ENDSUB(name).\n          ?  \n    --{ENDSUB}--  \n\nLa instrucción ENDSUB(name) señaliza la finalización del subprograma (subrutina) que se procesará luego de una instrucción de llamada a subprograma GOSUB(name).\n         ?  \n    --{GOSUB}--  \n\nLa instrucción GOSUB(name) habilita la llamada para el procesamiento de la correspondiente subrutina SUBPROG(name); puede implementarse como incondicional, al alcanzarse determinados escalones durante la ejecución del programa; o como condicional en función de la señal en su entrada lógica, provista por una instrucción previa.\nUna misma instrucción GOSUB (name) puede ser programada en diferentes escalones (rungs) del programa principal, tanto en forma condicional como incondicional.\nSi la señal en entrada lógica de la instrucción es 1 (ON, True), se procesará el correspondiente subprograma señalizado por la instrucción SUBPROG(name).\nSi la señal en entrada lógica de la instrucción es 0 (OFF, False), no se procesará la correspondiente instrucción SUBPROG(name) y la ejecución del programa continuará inmediatamente por la instrucción subsiguiente a la instrucción de llamada GOSUB(name).\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n    --{RETURN}--  \n\nLa instrucción RETURN permite interrumpir el procesamiento del subprograma SUBPROG(name) sin necesidad de completar su ejecución, o sea sin necesidad de alcanzar la correspondiente instrucción ENDSUB(name).\nDebe utilizarse siempre en forma condicional, es decir en función de la señal en su entrada lógica provista por una instrucción previa.\nLa instrucción RETURN puede ser programada en diferentes escalones (rungs) del subprograma, entre las correspondientes instrucciones SUBPROG(name) y ENDSUB(name), permitiendo diferentes condiciones de finalización del procesamiento del subprograma.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\nVer:\nGOTO and LABEL instruction\nSUBPROG, RETURN, ENDSUB and GOSUB, LABEL and GOTO instruction. Part 2\nSUBPROG, RETURN, ENDSUB and GOSUB, LABEL and GOTO instruction. Part 3\n"
  },
  {
    "title": "RESTABLECER TEMPORIZADOR DE CONTROL (WATCHDOG)",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#restablecer-temporizador-de-control-(watchdog)",
    "body": "    --{CLRWDT}--  \n\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), entonces se restablece (se pone a 0) la variable del temporizador WDT del microcontrolador.\nLDmicro ejecuta el comando CLRWDT automáticamente al comienzo de cada ciclo de PLC, por lo que puede utilizarse un CLRWDT adicional si el período del ciclo del PLC es mayor que el período del temporizador y WDT ha sido previamente habilitado modificando los bits de configuración del microcontrolador.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "BLOQUEAR EJECUCION",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#bloquear-ejecucion",
    "body": "    --{LOCK}--  \n\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), se ejecutará el comando LOCK.\nEl comando LOCK es un método para llevar a un punto muerto la ejecución del programa y está diseñado como un bucle cerrado. El comando LOCK ejecuta GOTO a la dirección actual, ej. labelN: GOTO labelN (label02e7: rjmp label02e7), es decir, resulta en un bucle infinito.\nEl microcontrolador ejecutará dicho bucle infinito, pero si el WDT ha sido previamente habilitado modificando los bits de configuración del microcontrolador, puede restablecer la ejecución del programa.\nSólo el WDT o un restablecimiento externo (mediante hard reset por !MCLR, o corte y restablecimiento de la alimentación del MCU) pueden descongelar el programa después de ejecutado el comando LOCK.\n"
  },
  {
    "title": "SUSPENDER",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#suspender",
    "body": "    --{SLEEP}--  \n\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), se establecerá el modo SLEEP (suspendido, modo de bajo consumo).\nPuede utilizarse para ahorrar energía cuando la alimentación del microcontrolador depende del suministro de una batería.\n\nPIC: puede salir del modo de suspensión mediante una interrupción externa de flanco ascendente en el pin RB0 / INT.\nPIC10xxxx: puede salir del modo de suspensión mediante un cambio de estado en los pines GP0, GP1, GP3.\nAVR: puede salir del modo de suspensión mediante interrupción externa de flanco ascendente en los pines PD2 / INT0, PD3 / INT1.\n\nLa operación SLEEP no afecta a otros pines de Entrada/Salida del microcontrolador ni a otras operaciones de LDmicro.\n\nNota:\nLa ejecución de la instrucción SLEEP alarga el tiempo de ciclo del PLC y los temporizadores TON, TOF, RTO, TCY.\n\nÉsto puede romper el flujo normal de trabajo del programa, provocando un error en la aplicación.\nEsta instrucción siempre debe ser programada en el extremo derecho del escalón (rung).\n"
  },
  {
    "title": "GENERADOR ALEATORIO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#generador-aleatorio",
    "body": "        var  \n    --{ RAND }--  \n\nEl generador de números pseudo-aleatorios devuelve un número al azar dentro del rango completo de la variable “var”.\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), la variable de destino “var” tendrá el siguiente número pseudo-aleatorio calculado por el generador congruencial lineal (LCG).\nSi la señal en la entrada lógica de esta instrucción es 0 (OFF, False), entonces nada sucede.\nEl generador se define por la relación de recurrencia:\n    X[n+1] = (a * X[n] + c) mod m  \n\nConstantes usadas desde el VMS MTH $ RANDOM, versiones antiguas de glibc:\n    a = 69069 ( 0x10DCD )  \n    c = 1 (0x01)  \n    m = 2^32  (0x100000000)  \n    X = (X * 0x10DCD + 0x01) % 0x100000000  \n\nRAND devuelve los bytes más significativos de X.\nX almacenado como $seed_Rand ( variable de 32 bits).\nVer Linear_congruential_generator\n"
  },
  {
    "title": "INICIALIZAR GENERADOR ALEATORIO",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#inicializar-generador-aleatorio",
    "body": "      {SRAND     Rand}  \n    --{$seed:=newSeed}--  \n\nEl generador de números pseudo-aleatorios se inicializa utilizando el argumento pasado como newSeed (semilla).\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), la variable de destino $seed_Rand será igual a la variable de origen o la constante.\nSi la señal en la entrada lógica de esta instrucción es 0 (OFF, False), entonces nada sucede.\nDos inicializaciones diferentes con la misma semilla generarán la misma sucesión de resultados en llamadas posteriores a RAND.\nSi la semilla se pone a 1, el generador ‘Rand’ se reinicializa a su valor inicial y produce los mismos valores que antes de cualquier llamada a RAND o SRAND.\nLas fuentes de entropía para la generación de la variable newSeed (semilla) pueden ser lecturas de la variable de un ADC (máxime si el pin de entrada no está conectado a circuito alguno y recibe inducción por fuentes externas), temporizadores, valores de RAND anteriores guardados en EEPROM, etc.\n"
  },
  {
    "title": "GENERADOR DE CARACTERES EN LED DE 7 SEGMENTOS",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#generador-de-caracteres-en-led-de-7-segmentos",
    "body": "      {7SEG    dest:=}  \n    --{C          src}--  \n\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), la variable destino “dest” destino un valor binario abcdefgP que controlará la activación de los segmentos y el punto decimal del display LED de 7 segmentos.\nLa variable “src” debe estar en el rango 0…127 ó 0…128, y usualmente puede tener un tamaño de 2 bytes, o de 1 byte si no utilizará el carácter ° (grado), código ASCII 128.\nUtilice el parámetro A ó C de la instrucción para especificar cuál tipo de conexión común (Ánodo o Cátodo) será utilizada.\nSe puede asignar un variable de acceso directo “#PORTx” como variable destino, de modo de controlar en forma directa un display conectado a los pines del puerto correspondiente, sin necesidad de utilizar instrucciones intermedias.\nLos pines de salida de dicho puerto podrían conectarse a directamente los ánodos (o cátodos) del display LED de 7 segmentos, a través de resistores de limitación de corriente.\n\nP. ej. para encender el segmento de LED “a”:\n\n\ncuando es utilizado un módulo con ánodo común, se requiere un nivel bajo en el pin “a” y un nivel alto en el pin común.\ncuando es utilizado un módulo con cátodo común, se requiere un nivel alto en el pin “a” y un nivel bajo en el pin común.\n\nVer NOTA abajo.\nDisplay de LED de 7 segmentos: identificación de cada segmento.\n     ___\n   f| a |b\n    |___| \n    | g |\n   e|___|c\n      d  ·P\n\n  |SEGMENTO   |P|g|f|e|d|c|b|a|  \n  |\"dest\" BIT |7|6|5|4|3|2|1|0|  \n\nEstán implementados 129 caracteres de la tabla de códigos ASCII.\nLos primeros 32 caracteres ASCII son reemplazados por los dígitos hexadecimales correspondientes 00 a FF.\nEl 129° código corresponde al símbolo ° (grados), utilizado habitualmente para mostrar un valor de temperatura o ángulo.\n  |ADDRESS  |   Low nibble   |   High nibble  |  \n  |  0(0x00)|0123456789ABCDEF 0123456789ABCDEF|  \n  | 32(0x20)| !\"#$%&'()*+,-./ 0123456789:;<=>?|  \n  | 64(0x40)|@ABCDEFGHIJKLMNO PQRSTUVWXYZ[\\]^_|  \n  | 96(0x60)|`abcdefghijklmno pqrstuvwxyz{|}~ |  \n  |128(0x80)|° (degree, 0x80)                 |\n\nCarácter \" \", espacio (en blanco): hex 0x20  \nCarácter DEL, eliminar (en blanco): hex 0x7F  \n\nVer X-segment LED display, font example\nNOTA DE APLICACION EN OSIMPLC:\nLa conexión directa del display de 7 segmentos a los transistores de  los optoacopladores de salida no debería realizarse con OSIMPLC. Es preferible utilizar módulos de salida a transistor de potencia O4T conectados a Y0-Y3 e Y4-Y7 (Y0=bit0; Y7=bit7): cada una de sus salidas admite una corriente máxima de 2A y está protegida por fusible y diodo de rueda libre y máxima tensión, permitiendo utilizar displays de LED de 7 segmentos de gran potencia lumínica.\nLas salidas Y8-YB podrían ser utilizadas para multiplexar las salidas de la instrucción 7SEG y controlar hasta 4 displays de 7 segmentos (4 dígitos, o 3 dígitos y signo).\nRecuerde que en OSIMPLC las salidas de transistor de potencia son MOSFET tipo N, la conexión  eléctrica del LED 7 segmentos debe ser NPN, sink (ánodo común).\nEn esta implementación, el parámetro de conexión común de la instrucción debe establecerse en C, de modo que la salida lógica para activar cada segmento resulte un 1, y un 0 para desactivarlo (al contrario de la conexión eléctrica).\n"
  },
  {
    "title": "CONVERSOR BINARIO A BCD",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#conversor-binario-a-bcd",
    "body": "  {BIN2BCD dest:=}  \n    --{src}--  \n\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), la instrucción convierte el valor binario 0bn de la variable “src” en un código BCD y lo transfiere a la variable “dest”.\n“src” puede ser un valor binario con tamaño 1, 2, 3 o 4 bytes.\n“dest” es un valor BCD “desempaquetado”, con tamaño 3, 5, 8 ó 10 bytes.\n“Desempaquetado” significa que cada numeral (dígito decimal) es codificado en un byte, donde los cuatro bits inferiores representan el numeral, y los cuatro bits superiores no tienen significancia.\n\nPor ejemplo:\nEl número decimal 99 (0x63) será convertido en código BCD en notación hexadecimal 0x000909.\nEl número decimal 100 (0x64) será convertido en código BCD en notación hexadecimal 0x010000.\n\nVer Binary-coded_decimal\n"
  },
  {
    "title": "CODIFICADOR DE CUADRATURA (QUAD ENCODER)",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#codificador-de-cuadratura-(quad-encoder)",
    "body": "      ~~[XqA0    XqB0&nbsp    qDir0]-  \n    --\\[XqZ0   QUAD ENCOD   qCount0]^--  \n\nLa instrucción Codificador de Cuadratura toma dos señales cuadradas desplazadas en 90° (señales A y B codificadas en cuadratura) y una tercera señal de reposición (señal Z) desde un dispositivo encoder rotativo incremental o lineal, y provee como salidas la variable de un contador interno de la instrucción, un pulso positivo en su salida lógica cuando hay un cambio en dicha variable, y una salida de señal en un relé interno R ó un pin Y del microcontrolador, para indicar la dirección de conteo.\n                        move ->             |            <- move\n         ^\n         | ___         _______         ___________          _______         ___\n  Input A|    |_______|       |_______|           |________|       |_______|\n         |\n         | _______         _______         ___         ________         _______\n  Input B|        |_______|       |_______|   |_______|        |_______|\n         |\n         |\n  Counter|  0 |   | 1 |   | 2 |   | 3 |   | 4 |   | 3 |   | 2 |   | 1 |   | 0\n         |\n   Output| ___________________________________   decrease or CCW or backward\n      Dir|    increase or CW or forward       |________________________________\n         |\n   Output|\n    Pulse| _______^_______^_______^_______^_______^_______^_______^_______^____\n         |\n       --+----------------------------------------------------------------> time\n         |\n           '^' - es un pulso con duración de 1 ciclo de PLC\n\nVer Incremental_encoder\nLa instrucción puede ser implementada con sólo dos entradas de señal (señal A -> XqAn y señal B->  XqBn), o bien con tres entradas de señal (utilizando también señal opcional Z -> XqZn), provenientes de los pines de entrada del microcontrolador.\nLa salida de señal opcional Dir (Dirección -> YqDirn) puede ser dirigida a un pin de salida del microcontrolador, o ser omitida.\nLas entradas lógicas para las señales A y B obligatoriamente deben asignarse a pines de entrada pertenecientes a un mismo puerto del microcontrolador (p. ej. RD0 y RD1).\nLa frecuencia de los pulsos en las entradas A y B debe ser menor a una cuarta parte de la frecuencia del ciclo de PLC (f[A,B] < fPLC/4), de lo contrario se perderán lecturas de pulsos, generando errores de conteo.\nLos rebotes de señal (bounces) que pudieran producirse en los pulsos de entrada en las señales A y B deben tener una duración menor a un octavo de ciclo del PLC (Tbounce[A,B] < Tcycle/8), de lo contrario  se producirán lecturas repetitivas de un mismo pulso, generando errores de conteo.\nLa entrada lógica para la señal Z es opcional y puede dejarse vacía (borrando el nombre de la variable asignada por defecto en la instrucción), sin asignarla a pin de entrada en el microcontrolador.\nLa salida lógica para la señal Dir es opcional y puede dejarse vacía (borrando el nombre de la variable asignada por defecto en la instrucción), sin asignarla a pin de salida en el microcontrolador.\nSi la señal en la entrada lógica de la instrucción es 1 (ON, True), entonces los pulsos en las entradas A, B y Z son decodificados y asignados al valor de la variable del contador interno de la instrucción (qCount0 por defecto).\nLa instrucción Codificador de Cuadratura ejecuta conteo doble, leyendo las transiciones (flancos positivos y negativos) que aparecen en la señal B y evaluando simultáneamente el nivel (0, 1) de la señal A.\nCuando un flanco en la señal lógica en la entrada B genera un conteo, se modificará la variable del contador interno qCount0 (incrementando o decrementando), se generará un pulso con duración de un ciclo de PLC en la salida lógica de la instrucción, y la señal en la salida opcional Dir será 1 (ON True) si el contador es incrementado, y 0 (OFF, False) si es decrementado.\nEl valor actual de la variable interna de conteo qCount0 puede leerse como en cualquier otra variable de contador, utilizando la instrucción MOV, y luego ejecutar sobre la variable destino las operaciones aritméticas y de comparación necesarias para la aplicación.\nNo es recomendado utilizar la instrucción MOV para asignar un valor a la variable del contador interno de la instrucción, a menos que resulte imprescindible para la aplicación.\nPara resolver pequeños errores en el conteo (pérdida o sobrelectura de algunos pulsos) se puede utilizar la entrada Z (ver abajo).\nConsejo: Utilice la salida lógica de pulsos de la instrucción para determinar si la variable del contador interno se ha modificado, no para efectuar el conteo (puede leer su valor actual desde la variable del contador interno de la instrucción).\nLa evaluación de la señal lógica en la entrada Z (reposición) puede ser dinámica (activada por flanco positivo o negativo), o estática (activada por nivel alto o bajo).\nSi el parámetro Count per revol de la instrucción es 0, al activarse la señal Z la variable del contador interno qCount0 será automáticamente restablecida a 0 (reset).\nSi el parámetro Count per revol de la instrucción es mayor que 0, al activarse la señal Z la variable del contador interno qCount0 será automáticamente establecida al siguiente múltiplo del parámetro Count per rev (mayor si la variable estaba incrementando, y menor si la variable estaba decrementando).\nSi el parámetro Count per revol de la instrucción es menor que 0, las señales en la entrada Z son ignoradas.\nSi la señal en la entrada lógica de la instrucción es 0 (OFF, False), entonces las señales en las entradas A, B y Z son ignoradas (no se procesan).\n\nNOTA:\nPara simular las señales lógicas en las entradas A, B y Z, debe hacer doble click sobre su nombre en la lista de variables en la zona inferior de la ventana de LDmicro.\n\nVea detalles en:\nIncremental-QUADRATURE-ENCODER\nIncremental QUADRATURE ENCODER controls the brightness of the LED (PWM out)\n"
  },
  {
    "title": "OPERACIONES DE COMUNICACION SERIAL DE DATOS POR UART (RECEPCION Y TRANSMISION)",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#operaciones-de-comunicacion-serial-de-datos-por-uart-(recepcion-y-transmision)",
    "body": "LDmicro puede generar código para utilizar el periférico UART incorporado en ciertos modelos de microcontroladores PIC y AVR.\nEn AVRs con múltiples UARTs, solamente UART1 (no UART0) puede ser implementado. Configure la velocidad de comunicación (baudrate) en baudios utilizando el menú Configuraciones -> MCU parámetros…\nEventualmente, no podrán obtenerse ciertas velocidades de comunicación en baudios, ya que se establecen en función de la frecuencia base del microcontrolador; LDmicro mostrará una advertencia si éste es el caso.\nEn LDmicro existen diferentes instrucciones disponibles para enviar caracteres individuales, bytes en modo binario (“crudo”) o cadenas de caracteres formateadas que incluyen un texto fijo, el valor de una variable y caracteres de control.\n\nNOTA:\nEs imprescindible asegurar que el buffer de salida de la UART está libre antes de tratar de enviar un nuevo carácter, byte en modo binario o cadena formateada.\n\nPara cumplir esta condición, usted puede utilizar diferentes estilos de programación:\n\nUtilice un tiempo de ciclo de PLC que resulte considerablemente mayor que el tiempo requerido para transmitir un solo carácter o byte en el baudrate deseado. P. ej., si configura el tiempo de ciclo en 10 ms (por defecto) y efectuará la comunicación utilizando un baudrate de 9600 bits por segundo, el tiempo de ciclo será aproximadamente 10 veces mayor al tiempo de transmisión de cada carácter.\nUtilice un temporizador para insertar un retardo entre caracteres o bytes durante la transmisión. El parámetro del temporizador debe ser mayor que el tiempo de transmisión del carácter o byte en la UART.\nCompruebe que el estado de la salida lógica de la instrucción de envío es 0 (OFF, False) para asegurar que el carácter o byte previo ya ha sido transmitido, antes de tratar de enviar un nuevo carácter o byte ; p. ej. envíe la salida de la instrucción UART SEND o UART SENDn a una bobina de un relé interno Rname, y utilice su contacto normal abierto como condición de entrada de la misma instrucción.\nUtilice la instrucción UART SEND: está listo? como condición de entrada de la instrucción UART SEND, UART SENDn o ENVIAR CADENA FORMATEADA POR UART.\n\n"
  },
  {
    "title": "RECIBIR CARACTER POR UART",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#recibir-caracter-por-uart",
    "body": "          var  \n    --{UART RECV}--  \n\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), UART RCV intenta recibir un solo carácter desde el buffer de entrada de la UART.\nSi efectivamente se lee un carácter, su valor ASCII se almacena en la variable \"var\"y la salida de la instrucción será 1 (ON, True) para un solo ciclo de escaneo de programa en el PLC.\nSi no se lee ningún carácter, entonces la salida de la instrucción será 0 (OFF, False).\nSi la señal en la entrada lógica de esta instrucción es 0 (OFF, False), entonces nada sucede.\n"
  },
  {
    "title": "ENVIAR CARACTER POR UART",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#enviar-caracter-por-uart",
    "body": "          var  \n    --{UART SEND}--  \n\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), entonces UART SEND escribirá un solo carácter en el buffer de salida de la UART. El valor ASCII del carácter debe ser previamente almacenado en “var”.\nLa salida de la instrucción es 1 (ON, True) si el UART está ocupado (transmitiendo actualmente un carácter), y 0 (OFF, False) en caso contrario.\nSi la señal en la entrada lógica de esta instrucción es 0 (OFF, False), entonces nada sucede.\nTenga en consideración que los caracteres tardan algún tiempo en transmitirse. Sólo se debe  activar la entrada lógica de la instrucción (intentar enviar un carácter) cuando el buffer de transmisión del UART no está ocupado.\n\nNOTA:\nLea más abajo respecto al uso de la instrucción ENVIAR CADENA FORMATEADA POR UART, antes de usar la instrucción UART SEND.\n\nLa instrucción para enviar una cadena formateada de caracteres es mucho más fácil de usar, y casi con toda seguridad es capaz de realizar la tarea de comunicación de datos que usted desea.\n"
  },
  {
    "title": "Actualización: Versiones >= v.4.4.0",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#actualizacion:-versiones-greater-v.4.4.0",
    "body": "Las instrucciones UART RCV y UART SEND permiten recibir/enviar variables de tamaño mayor a un solo byte.\nEl parámetro “Number of bytes to receive/send” debe ser igual o menor que el tamaño de la variable utilizada.\nEl valor 1 es compatible con versiones anteriores de LDmicro.\nEl parámetro “Wait until all bytes are received/transmitted:” controla el algoritmo\nde recepción/transmisión: si es igual a 1, todos los bytes son recibidos/transmitidos en un solo paquete; si es igual a 0, sólo se recibe/transmite un byte por ciclo de escaneo del PLC.\nEl valor 0 es compatible con versiones anteriores de LDmicro.\nCuando todos los bytes han sido recibidos/transmitidos, la salida de la instrucción será 1 (ON, True) durante un ciclo del PLC.\nVer UART communication FAQ part 2\n"
  },
  {
    "title": "ENVIAR BYTE EN MODO BINARIO POR UART",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#enviar-byte-en-modo-binario-por-uart",
    "body": "          var  \n    --{UART SENDn}--  \n\nSi la señal en la entrada lógica de esta instrucción es 1 (ON, True), entonces UART SEND escribirá una variable de un byte en formato binario (“crudo”) en el buffer de salida de la UART.\nSe envía un solo byte por cada ciclo de PLC, al igual que en la instrucción ENVIAR CADENA FORMATEADA POR UART.\nLa salida de la instrucción es 1 (ON, True) si el UART está ocupado (transmitiendo actualmente el byte en modo binario), y 0 (OFF, False) en caso contrario.\nSi la señal en la entrada lógica de esta instrucción es 0 (OFF, False), entonces nada sucede.\n"
  },
  {
    "title": "ENVIAR POR UART: está listo?",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#enviar-por-uart:-esta-listo",
    "body": "       Is ready?  \n    --[UART SEND]--  \n\nLa señal de entrada lógica de la instrucción no se evalúa (no se tiene en cuenta).\nLa salida es 1 (ON, True) cuando el buffer de transmisión de la UART está vacío y listo para transmitir nuevos datos, y 0 (OFF, False) en caso contrario.\n"
  },
  {
    "title": "RECIBIR POR UART: hay dato disponible?",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#recibir-por-uart:-hay-dato-disponible",
    "body": "       Is avail?  \n    --[UART RECV]--  \n\nLa señal de entrada lógica de la instrucción no se evalúa (no se tiene en cuenta).\nLa salida es 1 (ON, True) cuando hay datos no leídos en el buffer de recepción, y 0 (OFF, False) en caso contrario.\n"
  },
  {
    "title": "ENVIAR CADENA FORMATEADA POR UART",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#enviar-cadena-formateada-por-uart",
    "body": "             var  \n    --{\"value: \\c\\r\\n\"}--  \n\nCuando aparece un flanco positivo de la señal en la entrada lógica de esta instrucción (transición de 0 (OFF, False) a 1 (ON, True), se comienza a enviar una cadena completa de caracteres a través del puerto serie UART.\nEl texto “value:” puede ser reemplazado por cualquier texto fijo en función de los requerimientos de la aplicación.\nSi la cadena contiene la secuencia especial \\c, entonces esa secuencia será sustituída por el valor de la variable “var”, automáticamente convertido en una cadena de caracteres.\nLa variable “var” se formateará para ocupar exactamente c caracteres, por lo tanto c debe ser un número igual o mayor que la cantidad de caracteres que expresan la variable numérica en decimal.\nPor defecto, al programarse la instrucción en el esquema Ladder, LDmicro configura \\c en el valor 3 e incluye los caracteres de control \\r y \\n que generan los códigos ASCII para retroceso de carro y nueva línea, respectivamente.\nPor ejemplo, si se reemplaza “value:” por “Temp:”, \\c es igual a 3, la variable “var” contiene un valor igual a 35 y se conservan los caracteres de control por defecto, entonces la cadena transmitida será “Temp:  35” (note el espacio en blanco extra antes del valor de la variable), e incluirá automáticamente los comandos para retroceso de carro y nueva línea en el terminal serial.\nSi en cambio “var” fuera igual a 1432, entonces el comportamiento resultará indefinido, porque 1432 tiene más de tres dígitos. En ese caso sería necesario utilizar \\c igual a 4 para no generar un error.\nSi la variable puede ser negativa, utilice \\-3 o \\-4, etc. en su lugar. Esto hará que LDmicro imprima un espacio en blanco inicial \" \" al transmitir números positivos, y un signo menos “-” inicial al transmitir números negativos.\nTambién puede utilizar valores haxadecimales para conformar la cadena a enviar, p. ej. para enviar caracteres de control, o de la codificación ASCII extendida (rango de 0x80 a 0xFF).\nEs posible usar esta instrucción para dar enviar sólo texto, es decir una cadena fija de caracteres por UART sin interpolar el valor de una variable entera en el texto que se envía. En este caso, simplemente no incluya en la instrucción la secuencia de escape \\c correspondiente al número de caracteres de la variable. Sí puede incluir opcionalmente caracteres de control \\r, \\n y otros.\nUtilice “\\” si necesita escapar y enviar una barra invertida literal incluída en el texto fijo.\nAdemás de la secuencia de escape \\c para interpolar una variable, están disponibles las siguientes secuencias de escape:\n  | Sec |  Hex |        ASCII        | \n  | \\a  | 0x07 | BEL, Alert (Bell)   |\n  | \\b  | 0x08 | BS, Backspace       |\n  | \\e  | 0x1B | Escape character    |\n  | \\f  | 0x0C | FF, Formfeed        |\n  | \\n  | 0x0A | NL, Newline         |\n  | \\r  | 0x0D | CR, Carriage Return |\n  | \\t  | 0x09 | TAB, Horizontal Tab |\n  | \\v  | 0x0B | VT, Vertical Tab    |\n  | \\'  | 0x27 |Single quotation mark|\n  | \\\"  | 0x22 |Double quotation mark|\n  | \\?  | 0x3F |Question mark        |\n  | \\\\  | 0x5C |Backslash            |\n  | \\xhh|(byte)|hh range: 0x00..0xFF |  \n\nLa salida de esta instrucción es 1 (ON, True) mientras está transmitiendo datos, y 0 (OFF, False) en caso contrario.\nSi se activan simultáneamente múltiples instrucciones para enviar cadenas formateadas (o si una es energizada antes de que otra similar termine de ejecutarse), o si estas instrucciones son activadas simultáneamente con otros tipos de instrucciones para transmisión de datos por UART, entonces el comportamiento resultará indefinido.\nNOTA IMPORTANTE:\nEsta instrucción consume gran cantidad de memoria del programa, por lo que debe utilizarse con moderación. La implementación actual no es eficiente, pero para una mejor solución sería necesario realizar modificaciones en todos los back-ends.\n"
  },
  {
    "title": "OPERACIONES DE COMUNICACION DE DATOS POR BUSES I2C Y SPI, Y FORMATEO DE CADENAS DE CARACTERES",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#operaciones-de-comunicacion-de-datos-por-buses-i2c-y-spi-y-formateo-de-cadenas-de-caracteres",
    "body": "\nNOTA IMPORTANTE:\nLAS INSTRUCCIONES DESCRIPTAS A CONTINUACION NO PUEDEN SER PROGRAMADAS NI APLICADAS EN OSIMPLC V2.0.\n\nESTAS INSTRUCCIONES HAN SIDO DESARROLLADAS PARA PERMITIR LA COMUNICACION DE DATOS POR MEDIO DE LOS BUSES DE DATOS I2C Y SPI EN LOS MICROCONTROLADORES EN LOS CUALES TIENEN SOPORTE, Y PARA OBJETIVOS TIPO NETZER (ETHERNET ON 8 BIT MICROCONTROLLERS) DONDE HA SIDO IMPLEMENTADA LA FUNCION printf().\nHAN SIDO INCLUÍDAS EN ESTE MANUAL A MODO DE ILUSTRACION DE LAS POSIBILIDADES DE PROGRAMACIÓN INCLUIDAS EN LDMICRO, Y PARA MANTENER COMPATIBILIDAD CON EL MANUAL EN ESPAÑOL PROVISTO JUNTO CON EL SOFTWARE.\nRazones de la exclusión de estas instrucciones en OSIMPLC:\n\nLos buses I2C y SPI no están regulados bajo la normativa IEC 61131, y no son estándar en implementaciones de autómatas programables del tipo PLC.\nEn el hardware de OSIMPLC, todos aquellos pines del microcontrolador que ofrecen acceso a periféricos que controlan dichos buses se han implementado como entradas y salidas digitales o como entradas analógicas normalizadas (es decir, como señales estándar en PLCs industriales).\nLas instrucciones de control de los buses I2C y SPI en LDmicro sólo están disponibles para microcontroladores de la línea ARM de 32 bits y algunos modelos de la línea AVR ATmega. OSIMPLC se ha desarrollado teniendo como objetivo de primera instancia la utilización de microcontroladores de la línea PIC de Microchip (aunque no se descartan próximas implementaciones con microcontroladores AVR ATmega).\nLa compilación de las instrucciones de control para los buses I2C y SPI requiere:\na) Utilizar un programa compilador externo (AVR-GCC ó ARM-GCC) para recompilar el código generado en lenguaje C por LDmicro junto con las bibliotecas de funciones en C correspondientes, mediante los menús “Compile Atmel AVR-GCC” o “Compile ARM-GCC”;\nb) completar la generación del archivo .hex (código máquina) por medio del menú “FlashMCU” en LDmicro;\nc) si el correspondiente archivo flashMcu.bat está correctamente configurado, descargar el código máquina en el microcontrolador AVR o ARM utilizando el software de programación (“quemador”) y el hardware correspondiente a cada línea (AVR o ARM).\nEstos procedimientos exceden el alcance y los propósitos del proyecto OSIMPLC.\n\n"
  },
  {
    "title": "SPI ENVIAR / RECIBIR",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#spi-enviar-recibir",
    "body": "      {SPI      SPI1}  \n    --{->recv send->}--  \n\nSólo un bus SPI puede ser programado en un mismo esquema Ladder, llamado SPI, o SPI1, SPI2 ó SPI3 cuando hay varios buses implementados en el microcontrolador.\nSPI sólo trabaja en modo maestro, con datos de 8 bits, enviando/recibiendo el MSB primero, y su frecuencia debe ser establecida en los parámetros del microcontrolador mediante el menú Configuraciones > MCU parámetros…\nEl pin SS es controlado por el código en los microcontroladores AVR, pero no en los ARM. Puede utilizarse pines externos para activar / desactivar los esclavos en el bus SPI, y/o el pin SS en AVR.\nEn un bus SPI, el envío y la recepción son simultáneos, por eso ambas operaciones han sido incluídas en una sola instrucción.\n"
  },
  {
    "title": "SPI ESCRIBIR",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#spi-escribir",
    "body": "      {SPI_WR  SPI}  \n    --{\"Message\"->}--  \n\nLa instrucción SPI_WR envía una cadena de caracteres por el bus SPI, sin tener en consideración la existencia de datos entrantes.\nLa cadena puede contener caracteres especiales precedidos por \\\\.\nNo abusar de esta instrucción, porque puede ralentizar la ejecución del programa y generar inconvenientes en el control del tiempo de ciclo de PLC.\n"
  },
  {
    "title": "I2C LEER",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#i2c-leer",
    "body": "      {I2C_RD    I2C}  \n    --{->recv 0x20 0}--  \n\nLa instrucción I2C READ lee un byte desde la dirección dada del registro en el esclavo especificado.\n"
  },
  {
    "title": "I2C WRITE",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#i2c-write",
    "body": "      {I2C_WR    I2C}  \n    --{0x20 0 send->}--\n\nLa instrucción I2C WRITE escribe un byte a la dirección dada del registro en el esclavo especificado.\n"
  },
  {
    "title": "FORMATEAR CADENA DE CARACTERES",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#formatear-cadena-de-caracteres",
    "body": "           dest  \n    --{\"string\", var}--  \n\nEsta instrucción puede ser usada para generar código compilado para objetivos como Netzer, que cuentan con implementaciones de printf preexistentes.\nCuando aparece un flanco positivo de la señal en la entrada lógica de esta instrucción (transición de 0 (OFF, False) a 1 (ON, True), comienza a procesar la cadena con printf y escribe el resultado en el registro de destino.\nLa instrucción embebe completamente la cadena en la imagen resultante.\nLa variable “var” puede ser cualquier registro del programa y es utilizada como marcador de posición para printf. La función printf accede al registro si se encuentra un marcador de posición de estilo printf (p. ej. %d).\ndest es un registro donde se escribe el resultado. Éste debería ser la entrada superior de un buffer FIFO o LIFO.\nLa salida de la instrucción es siempre 1 (ON, True)."
  },
  {
    "title": "NOTA PARA EL USO DE FUNCIONES MATEMATICAS",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#nota-para-el-uso-de-funciones-matematicas",
    "body": "Actualización a versiones >= v.4.4.0\nRecuerde que LDmicro realiza operaciones matemáticas sólo con variables enteras con signo de 8, 16, 24 ó 32 bits.\nÉsto significa que el resultado final de cualquier cálculo que se realice debe ser un entero entre dentro del rango del operando de mayor tamaño utilizado en la instrucción. También significa que los resultados intermedios de los cálculos deben estar dentro de ese rango.\nOperaciones aritméticas con variables de distinto tamaño (alcance, span) podrían dar lugar a resultados inesperados.\nEs recomendable que las variables que alojarán a todos los operandos, a los resultados parciales en las sucesivas operaciones intermedias, y al resultado final, posean el mismo tamaño y éste sea igual a o mayor que el de la variable de mayor tamaño.\nATENCION:\nTenga muy en consideración que LDmicro sólo efectúa operaciones con variables de números enteros.\nPor ejemplo, digamos que usted desea calcular temp = (1 / x) * 1200, donde x está entre 1 y 20.\nEntonces y tendrá un resultado entre 1200 y 60, que se ajusta a un entero de 16 bits, por lo que al menos en teoría es posible realizar el cálculo si inconvenientes.\nHay dos modos de codificar ésto:\na) Podría realizar el recíproco, y luego multiplicar:\n  ||  {DIV temp  := }  \n  ||--{ 1 / x       }--  \n  ||\n  ||  {MUL  y    := }  \n  ||--{ temp * 1200 }--  \n  ||\n\nb) Simplemente podría hacer la división directamente, en un solo paso:\n  ||  {DIV  y  :=}  \n  ||--{ 1200 / x }--  \n\nMatemáticamente, estos dos cálculos son equivalentes; pero si usted los intenta, encontrará que el primero modo da un resultado incorrecto de y = 0, salvo en el caso en que x = 1.\nÉsto es debido a que en el modo a) la variable “temp” siempre tendrá un resultado menor que 1 si el dividendo es mayor que 1 (underflow ó desbordamiento inferior), y ese resultado es truncado por la instrucción de la división.\nPor ejemplo, cuando x = 3 => (1 / x) = 0,333, pero este resultado no es un número entero, y  la operación de división aproxima ésto como temp = 0.\nEl resultado de la segunda operación, la multiplicación, será y = temp * 1200 = 0, generando un error.\nEn el segundo modo, b) no hay ningún resultado intermedio menor a 1 que cause desbordamiento inferior, así que todo funcionará como es esperado.\nSin embargo, note que los resultados son truncados, lo que significa los decimales serán eliminados en la variable que alojará el resultado.\nSi usted está encontrando problemas con sus matemáticas, compruebe los resultados intermedios para verificar que no exista desbordamiento inferior (número menor de la unidad mínima de la variable) o desbordamiento superior, por ejemplo, 32767 + 1 = -32768 si se está trabajando con variables int16 con signo.\nCuando necesite escalar una variable por algún factor, hágalo usando primero una multiplicación y luego una división, pero siempre verificando que la primera operación no resulte en desbordamiento superior (overflow).\nPor ejemplo, para escalar y = 1,8 * x, calcule y = (9/5) * x (que es el mismo, ya que 1,8 = 9/5), y programe el código de éste como y = (9 * x) / 5, realizando primero la multiplicación:\n  ||  {MUL  temp  :=}  \n  ||--{ x * 9       }--  \n  ||  \n  ||  {DIV  y  :=}  \n  ||--{ temp / 5 }--  \n\nÉsto funcionará para todos los valores x < 32767/9, o x < 3640.\nPara valores mayores de x, la variable `temp 'se desbordará. Hay un límite inferior similar en x."
  },
  {
    "title": "ESTILO DE CODIFICACION",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#estilo-de-codificacion",
    "body": "1.\nEstá permitida la programación de múltiples bobinas u otras operaciones (aritméticas, MOV, etc.) en paralelo en un solo escalón (rung).\nÉsto significa que usted puede hacer programaciones como la siguiente:\n  ||        Xa               Ya  \n  ||-------] [--------------( )--  \n  ||  \n  ||        Xb               Yb  \n  ||-------] [------+-------( )--  \n  ||                |  \n  ||                |        Yc  \n  ||                +-------( )--  \n  ||  \n\nque resulta equivalente a ésta:\n  ||        Xa               Ya  \n  ||-------] [--------------( )--  \n  ||\n  ||        Xb               Yb  \n  ||-------] [--------------( )--  \n  ||\n  ||        Xb               Yc  \n  ||-------] [--------------( )--  \n  ||  \n\nÉsto significa que en teoría se podría escribir cualquier programa como una sola línea gigante, y no habría necesidad de utilizar múltiples escalones en absoluto.\nEn la práctica ésto sería una mala idea, porque como los líneas se vuelven más complejas se hace mucho más difícil de editar sin borrar y redibujar una gran cantidad de lógica.\nAún así, a menudo es una buena idea agrupar la lógica relacionada en un solo escalón.\nÉsto genera un código casi idéntico a si se hiciera en escalones separados, pero claramente muestra que están relacionados cuando se ven en el diagrama de contactos.\n2.\nEn general, se considera mala práctica escribir el código de tal manera que su salida dependa del orden de los escalones. Por ejemplo, este código no es muy bueno si tanto Xa como Xb pueden ser verdaderos:\n  ||        Xa        {v  :=   }  \n  ||-------] [--------{ 12  MOV}--  \n  ||  \n  ||        Xb        {v  :=   }  \n  ||-------] [--------{ 23  MOV}--  \n  ||  \n  ||       [v>]              Yc  \n  ||------[ 15]-------------( )-- \n  ||  \n\nSin embargo, puede romper esta regla si al hacerlo logra programar un segmento de código significativamente más compacto o efectivo.\nPor ejemplo, he aquí cómo haría para que el código convierta una cantidad binaria de 4 bits leída en Xb3:0 en una variable de un entero (o de un byte) con signo:\n  ||                   { v  :=    }  \n  ||-------------------{ 0     MOV}--  \n  ||  \n  ||       Xb0         { ADD  v :=}  \n  ||-------] [---------{ v + 1    }--  \n  ||  \n  ||       Xb1         { ADD  v :=}  \n  ||-------] [---------{ v + 2    }--  \n  ||\n  ||       Xb2         { ADD  v :=}  \n  ||-------] [---------{ v + 4    }--  \n  ||  \n  ||       Xb3         { ADD  v :=}  \n  ||-------] [---------{ v + 8    }--  \n  ||\n\nEn el primer escalón, la instrucción MOV pone a cero (resetea) la variable v antes de que las siguientes instrucciones le asignen un nuevo valor en función de las señales leídas en los contactos asignados a entradas físicas.\nSi la instrucción MOV se moviera al escalón inferior de este segmento de programa en lugar de estar ubicada en el escalón superior, entonces el valor de v sería siempre 0 cuando se leyese en cualquier otro sector del programa (antes o después del segmento).\nLa salida de este código depende por lo tanto del orden en que se evalúan las instrucciones.\nTeniendo en cuenta lo engorroso que sería codificar ésto de otra manera, es aceptable.\n\nNOTA: en versiones >= 3.X también es posible utilizar instrucciones como SetBit para efectuar la asignación de un 1 en cada bit de la variable destino v.\n"
  },
  {
    "title": "ABREVIATURAS",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#abreviaturas",
    "body": "\nPLC - controlador lógico programable.\nPWM - modulación de ancho de pulso.\nADC - convertidor analógico a digital.\nUART - Receptor Transmisor Asíncrono Universal\nPCB - placa de circuito impreso\n"
  },
  {
    "title": "ERRORES",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#errores",
    "body": "LDmicro no genera código muy eficiente; es lento de ejecutar, y desperdicia mucho de la capacidad de memoria Flash y RAM. A pesar de esto, un microcontrolador PIC de rango medio o un AVR ATmega pueden ejecutar casi todo lo que un pequeño PLC puede hacer, si se trata de tareas simples.\nLa longitud máxima de los nombres de las variables es muy limitada. Ésto es para gráficamente que encajen muy bien en el diagrama Ladder, así que no hay una buena solución a este incoveniente.\nSi su programa es demasiado grande para el tiempo de ciclo de PLC, o las memorias de programa o de datos tienen restricciones en el dispositivo que ha elegido, probablemente no lo obtendrá ningún indicio de error. Muy probablemente, la ejecución del código máquina se “colgará” en algún lugar.\nSe pueden desarrollar técnicas de programación y depuración que le ayuden a resolver ésto.\nLa programación descuidada en las rutinas de carga ó almacenamiento de los archivos .ld y .hex hace probable que resulte posible bloquear o ejecutar código arbitrario en el dispositivo, al cargarse un archivo .ld corrupto o generado malintencionadamente.\nPor favor, informe de errores adicionales o solicitudes de características al autor.\n\nGracias a:\n\nMarcelo Solano, por reportar un error de interfaz de usuario bajo Win98\nSerge V. Polubarjev, por informar que RA3: 0 en elPIC16F628 no funcionaba y también indicar cómo solucionarlo\nMaxim Ibragimov, por reportar y diagnosticar problemas mayores con los objetivos ATmega16 y ATmega162 hasta entonces no probados\nBill Kishonti, por informar que el simulador se colgaba cuando el programa en Ladder efectuaba división por cero\nMohamed Tayae, por reportar que las variables persistentes fueron rotas en el PIC16F628\nDavid Rothwell, por reportar varios errores en la interfaz de usuario y un problema con la función “Exportar como texto”\n\nEXENCION DE RESPONSABILIDAD\nNO UTILICE CODIGO GENERADO POR LDMICRO EN APLICACIONES DONDE UNA FALLA EN EL SOFTWARE PODRIA RESULTAR EN PELIGRO A LA VIDA HUMANA O EN DAÑO A LA PROPIEDAD.\nEL AUTOR NO ASUME NINGUNA RESPONSABILIDAD POR LOS DAÑOS RESULTANTES DE LA OPERACION DE LDMICRO O POR EL CODIGO GENERADO POR LDMICRO.\nLICENCIA DE USO, COPIA Y MODIFICACION\nEste programa es software libre: puede usarlo, redistribuirlo y/o modificarlo bajo las condiciones de la Licencia Pública General GNU (GPL) publicada por la Free Software Foundation, ya sea la versión 3 de la Licencia, o a su elección, cualquier versión posterior.\nEste programa se distribuye con la esperanza de que sea útil, pero SIN NINGUNA GARANTIA; sin la garantía implícita de COMERCIABILIDAD O APTITUD PARA UN PROPOSITO PARTICULAR.\nVea la Licencia Pública General de GNU (GPL) para más detalles.\nDebería haber recibido una copia de la Licencia Pública General de GNU (GPL) junto con este programa. Caso contrario, vea http://www.gnu.org/licenses/.\nJonathan Westhues\nRijswijk      -- Dec 2004  \nWaterloo ON   -- Jun, Jul 2005  \nCambridge MA  -- Sep, Dec 2005; Feb, Mar 2006; Feb 2007  \nSeattle WA    -- Feb 2009  \n\nEmail: jwesthues at cq dot cx\n"
  },
  {
    "title": "LDmicro: SOPORTE, INFORMACION, WIKI",
    "pagetitle": "Manual LDmicro - OSIMPLC",
    "slug": "LDmicro_manual.html#ldmicro:-soporte-informacion-wiki",
    "body": "LDmicro Forum:  http://cq.cx/ladder-forum.pl\nActual desarrollador: Ihor Nehrutsa (¡Muchas gracias!!!)\nÚltima versión: https://github.com/LDmicro/LDmicro/releases\nRepositorio: https://github.com/LDmicro/LDmicro\nWiki: https://github.com/LDmicro/LDmicro/wiki\nEmail: LDmicro.GitHub@gmail.com\nTraducción de esta versión y adaptación del manual al español para OSIMPLC:\nDaniel Hernando Mirkin\nEmail: danielmirkin at gmail dot com"
  },
  {
    "title": "Manual OBootLin - OSIMPLC",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html",
    "body": "OBootLin es un programa que permite descargar en la memoria Flash de OSIMPLC el archivo *.hex (INTEL IHEX) que contiene el código máquina compilado por LDmicro a partir de un esquema Ladder (archivo *.ld), o generado por medio de otros softwares de programación y sus compiladores.\nOBootLin corre bajo sistemas operativos GNU/Linux, y tiene licencia GPLv2.\nOBootLin es una versión ligeramente modificada de TinyBootloaderLin, y utiliza firmwares adaptados para los microcontroladores preinstalados en OSIMPLC: PIC16F887 (estándar) y PIC18F4520 (alternativo), con oscilador por cristal externo a 20 MHz.\nEstos firmwares son totalmente compatibles con otros softwares libres y privativos que pueden realizar la misma tarea, todos ellos derivados del original Tiny Pic Bootloader TPBL: TinyBootloaderLin (original y fork), bajo S.O. GNU/Linux; TPBLwin y MultiBootloader+, bajo S.O. Windows.\n"
  },
  {
    "title": "Instalar OBootLin",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#instalar-obootlin",
    "body": ""
  },
  {
    "title": "Descargar OBootLin:",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#descargar-obootlin:",
    "body": "Desde la página Descargas, descargue el archivo OBootLin.zip"
  },
  {
    "title": "Dependencias requeridas",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#dependencias-requeridas",
    "body": ""
  },
  {
    "title": "Arch Linux:",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#arch-linux:",
    "body": "python python-pyserial python-wxpython"
  },
  {
    "title": "Debian, Ubuntu y derivadas",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#debian-ubuntu-y-derivadas",
    "body": "python3 python3-serial python3-wxgtk4.0"
  },
  {
    "title": "Fedora:",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#fedora:",
    "body": "python3 python3-pyserial python3-wxpython4"
  },
  {
    "title": "Instalación",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#instalacion",
    "body": "No se requiere ningún proceso especial de instalación.\nSimplemente, descomprimir el archivo OBootLin.zip en un nuevo subdirectorio dentro del directorio /home/$USER, preferentemente junto al subdirectorio donde se instaló LDmicro.\n"
  },
  {
    "title": "Usar OBootLin",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#usar-obootlin",
    "body": ""
  },
  {
    "title": "Comunicar OSIMPLC con la PC:",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#comunicar-osimplc-con-la-pc:",
    "body": "\n\nConectar el Cable de Programación de OSIMPLC, o un adaptador USB-TTL genérico, al puerto USB en la PC y al conector TTL (pinout) en OSIMPLC.\nBajo GNU/Linux, el cable de programación o el adaptador aparecerán como un dispositivo /dev/ttyUSB[0-9].\n\n\nComprobar la asignación de puerto desde una terminal virtual:\n\n\n[$USER@$hostname ~]$ ls -l /dev | grep ttyUSB\ncrw-rw----  1 root uucp    188,   0 mar  2 13:13 ttyUSB0\n\n\nNota: si otro adaptador USB-serial ha sido conectado previamente, el cable de programación o nuevo adaptador USB-serial genérico será renumerado como /dev/ttyUSB1, y así sucesivamente.\n\nIMPORTANTE:\nEl usuario debe ser agregado al grupo que permite acceso a los dispositivos USB-serial (se requieren permisos de root):\nArch Linux y otras (Fedora, openSUSE): grupo uucp.\nDebian, Ubuntu y derivativas: grupos dialout y plugdev."
  },
  {
    "title": "Ejecutar OBootLin:",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#ejecutar-obootlin:",
    "body": "\nEn un terminal virtual, navegar al subdirectorio OBootLin: [$USER@$hostname ~]$ cd /home/$USER/../OBootLin/\nEjecutar OBootLin mediante python3: [$USER@$hostname ObootLin]$ python3 obootlin.py\nAlternativamente, se puede generar un lanzador OBootLin.desktop que permitirá ejecutar automáticamente OBootLin, sin necesidad de hacerlo desde una terminal virtual. Se pueden instalar copias del archivo OBootLin.desktop en diferentes directorios personales: Escritorio (Desktop) y/u otros. Utilizar un editor de texto para copiar y modificar el siguiente ejemplo de lanzador: OBootLin.desktop\n\n     [Desktop Entry]\n     Name=OBootLin\n     Exec=/home/$USER/ruta/al/directorio/OBootLin/obootlin.py\n     Type=Application\n     StartupNotify=true\n     Path=/home/$USER/ruta/al/directorio/OBootLin/\n     Icon=/home/$USER/ruta/al/directorio/OBootLin/modules/images/obootlin.png\n"
  },
  {
    "title": "Configurar el puerto y baudrate en la interfaz gŕafica de OBootLin:",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#configurar-el-puerto-y-baudrate-en-la-interfaz-grafica-de-obootlin:",
    "body": "En la sección de configuración de OBootLin (izquierda abajo), configurar:\n\nVelocidad de transmisión (baudrate): en la lista desplegable Comm, seleccione 19200 (obootlin.py utiliza 19200 baudios por defecto para la programación y la comprobación).\nBúsqueda de puerto: presione el botón Search, el campo de texto Comm mostrará el puerto virtual /dev/ttyUSB[0-9] asignado al cable de programación o al adaptador USB-TTL genérico. En caso de error, mostrará el mensaje “No serial ports detected”.\nCampo de texto Comm: alternativamente, se puede establecer manualmente el puerto /dev/ttyUSB[0-9], de acuerdo a la asignación del S.O. (ver arriba: comprobar la asignación de puerto).\nEs conveniente marcar la opción Check File, para evitar transferir programas corruptos o inexistentes.\nSi se utiliza el cable de programación de OSIMPLC o un adaptador USB-TTL genérico, no es necesario marcar la opción RTS (RequestToSend); ést0 sólo podría ser requerido para realizar la comunicación por puerto serie nativo DB9 ttyS[0-3], actualmente obsoleto.\n"
  },
  {
    "title": "Comprobar la comunicación e identificación de OSIMPLC:",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#comprobar-la-comunicacion-e-identificacion-de-osimplc:",
    "body": "\n\nEn la sección de comando de OBootLin (izquierda arriba), presionar el botón CheckPIC y mientras la barra de progreso está avanzando (timeout), en OSIMPLC presionar y soltar inmediatamente el botón RESET.\n\n\nSi la operación resulta existosa, la pestaña Messages mostrará:\n\n\n  Connected to /dev/ttyUSB0 at 19200\n  Searching for PIC ...\n  Found:16F 886/887 [18F 452o]\n\n\nEn caso de error, mostrará el mensaje: “Could not connect to ttyUSB0 at 19200 ERROR!” si no puede establecer la comunicación con el cable de programación o adaptador USB-TTL;\no el mensaje: “Connected to /dev/ttyUSB0 at 19200 Searching for PIC… Not found ERROR!” si OSIMPLC no tiene alimentación, se encuentra aún reseteado o existe algún otro inconveniente.\n"
  },
  {
    "title": "Transferir el programa de usuario (compilado a código máquina) a OSIMPLC:",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#transferir-el-programa-de-usuario-(compilado-a-codigo-maquina)-a-osimplc:",
    "body": "\n\nSeleccionar el archivo *.hex a transferir (compilado por LDmicro u otro software) utilizando el botón Browse (arriba a la derecha). Se abrirá el cuadro de diálogo SelectHexFile que permite navegar por directorios y subdirectorios, y seleccionar el archivo que contiene el correspondiente programa de usuario.\n\n\nEn la sección de comando de OBootLin (izquierda arriba) presionar el botón Write Flash, y mientras la barra de progreso está avanzando (timeout), en OSIMPLC presionar y soltar inmediatamente el botón RESET.\n\n\nSi la operación resulta exitosa, la pestaña Messages mostrará:\n\n\n  Connected to /dev/ttyUSB0 at 19200\n  HEX:xx days old,INX32M,16Fcode+cfg,total=xxxx bytes.\n  Searching for PIC ...\n  Found:16F 886/887\n  Write OK at hh:mm time: x.xxx sec\n\n\nEn caso de error, mostrará el mensaje: “Could not connect to ttyUSB0 at 19200 ERROR!” si no puede establecer la comunicación con el cable de programación o adaptador USB-TTL;\no el mensaje: “Connected to /dev/ttyUSB0 at 19200 HEX:xx days old,INX32M,16Fcode+cfg,total=xxx bytes.  Searching for PIC …Not found”, si OSIMPLC no tiene alimentación, se encuentra aún reseteado o existe algún otro inconveniente.\n"
  },
  {
    "title": "Enviar y recibir datos del OSIMPLC por medio del terminal serial virtual incluído:",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#enviar-y-recibir-datos-del-osimplc-por-medio-del-terminal-serial-virtual-incluido:",
    "body": "NOTA:\nPara efectuar la comunicación entre OSIMPLC y la PC, puede utilizarse el cable de programación, un adaptador USB-TTL o un adaptador USB-RS485.\n\nEn la pestaña Terminal: seleccionar la velocidad de transmisión (baudrate) utilizando la lista desplegable.\n\n\nNOTA: la velocidad de transmisión (baudrate) de datos mediante UART en el programa de usuario puede ser diferente de la velocidad utilizada por OSIMPLC para programación y comprobación (19200), y debe ser definida en el menú MCU parameters de LDmicro (o en el menú/configuración correspondiente en otros softwares).\n\n\n\nIniciar la comunicación: presionar el botón Open.\n\n\nRecibir datos:\n\n\nSi OSIMPLC está enviando datos por su puerto serie (TTL o RS-485), éstos serán mostrados en el campo de texto.\nUtilizando la lista desplegable Rx, el usuario puede ver los datos como Char (carácter) o Hex (códigos hexadecimales).\nMientras el puerto de comunicaciones permanece abierto, el usuario puede seleccionar y copiar el contenido del campo de texto (datos enviados por OSIMPLC).\n\nEnviar datos:\n\nUtilizando la lista desplegable Tx, el usuario puede enviar datos como Char (carácter).\nEl usuario puede tipear los datos (caracteres) en el campo de texto Tx, o copiarlos desde un archivo y pegarlos en dicho campo.\nLuego, debe presionar el botón Send, o la tecla Enter en el teclado para ejecutar el envío.\nOtros modos de datos (char, Type, TypEcho) pueden ser también utilizados.\n\nFinalizar la comunicación: presionar el botón Close.\n\n"
  },
  {
    "title": "Historia del Software",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#historia-del-software",
    "body": ""
  },
  {
    "title": "OBootLin",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#obootlin",
    "body": "http://www.osimplc.com/downloads\nEste código derivado es una versión ligeramente modificada de Tiny Pic Bootloader for GNU/Linux, Luis Claudio Gamboa fork.\nEl módulo pictype.py ha sido modificado, sólo contiene identificadores para los microcontroladores PIC16F887 y 18F4520.\nAdemás, sólo contiene firmware (archivos .hex) para los microcontroladores PIC16F887 y 18F4520 con oscilador por cristal externo a 20 MHz."
  },
  {
    "title": "Tiny Pic Bootloader for GNU/Linux, Luis Claudio Gamboa fork",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#tiny-pic-bootloader-for-gnulinux-luis-claudio-gamboa-fork",
    "body": "https://github.com/lcgamboa/tinybldlin\nEste código derivado es una versión modificada para permitir diferentes tamaños de bootloader (firmware), definidos por el usuario en el módulo “modules/pictype.py”.\nAdemás, el código original ha sido convertido para ser utilizado con el intérprete de python3 (a partir del año 2020, python2 quedará obsoleto y no dispondrá de actualizaciones ni soporte).\nÚltima versión: d7cf21b, 16 Diciembre 2018."
  },
  {
    "title": "Tiny Pic Bootloader for GNU/Linux",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#tiny-pic-bootloader-for-gnulinux",
    "body": "http://tinybldlin.sourceforge.net/\nEl software Tiny Pic Bootloader for GNU/Linux original fue escrito por Fernando Juarez V.\nTiny Pic Bootloader for GNU/Linux es licenciado bajo GPL v2.\nTinybldLin fue escrito en python2 utilizando los módulos python-serial y wxphython; puede ser ejecutado en cualquier distribución GNU/Linux (y quizás mac) que tenga instaladas dichas dependencias.\n\n“Esta versión pretende ser más que un clon del tinybldWin.exe original; pretende, en el futuro, agregar nuevas características y mejorar las existentes en el original.”\n\nÚltima versión: tinybldlin-0.8.1-src.tar.gz, 15 Noviembre 2012."
  },
  {
    "title": "Tiny Pic Bootloader for Windows",
    "pagetitle": "Manual OBootLin - OSIMPLC",
    "slug": "OBootLin_manual.html#tiny-pic-bootloader-for-windows",
    "body": "http://www.etc.ugal.ro/cchiculita/software/picbootloader.htm\nTiny Pic Bootloader (tinybld) fue escrito por Claudiu Chiculita, quien desarrolló el firmware (bootloader) y las primeras versiones del software para Windows (bajo Delphi).\nLos firmwares de tinybld son los bootloaders más pequeños disponibles para PICs, ocupan un máximo de 100 palabras (200 bytes) para aquellos dispositivos de las líneas 16F, 18F, dsPIC30 que soportan autoprogramación (self programming).\nTiny Pic Bootloader for Windows es un programa gratuito (freeware), pero no tiene una licencia de software libre, ni está disponible su código fuente.\nÚltima versión: TinyBld-1_10_6_pc_beta.zip, 18 Junio 2011."
  },
  {
    "title": "Descargas - OSIMPLC",
    "pagetitle": "Descargas - OSIMPLC",
    "slug": "downloads.html",
    "body": "\n\nLDmicro v5.3.0.4\n\n\nTiny Multi Bootloader+:\n\nsoftware\nfirmware\n\n\n\nOBootLin (fork of tinybldloader, by OSIMPLC)\n\n"
  }
]);
(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
// From [weex website] https://weex-project.io/js/common.js

window.Search = function (keywords) {
  var matchingResults = []
  var data = window.__searchindex

  keywords = keywords.trim().split(/[\s\-\，\\/]+/)

  for (var i = 0; i < data.length; i++) {
    var post = data[i]
    var isMatch = false
    var postTitle = post.title && post.title.trim(),
        postContent = post.body && post.body.trim(),
        postUrl = post.slug || '',
        postType = post.pagetitle
    var matchingNum = 0
    var resultStr = ''

    if(postTitle !== '' && postContent !== '') {
      keywords.forEach(function(keyword, i) {
        var regEx = new RegExp(keyword, "gi")
        var indexTitle = -1,
            indexContent = -1,
            indexTitle = postTitle.search(regEx),
            indexContent = postContent.search(regEx)

        if(indexTitle < 0 && indexContent < 0){
          isMatch = false;
        } else {
          isMatch = true
          matchingNum++
          if (indexContent < 0) {
            indexContent = 0;
          }

          var start = 0,
              end = 0

          start = indexContent < 11 ? 0 : indexContent - 10
          end = start === 0 ? 70 : indexContent + keyword.length + 60
          if (end > postContent.length) {
            end = postContent.length
          }

          var matchContent = '...' +
            postContent
              .substring(start, end)
              .replace(regEx, "<em class=\"search-keyword\">" + keyword + "</em>") +
              '...'

          resultStr += matchContent
        }
      })

      if (isMatch) {
        var matchingPost = {
          title: escapeHtml(postTitle),
          content: resultStr,
          url: postUrl,
          type: postType,
          matchingNum: matchingNum
        }

        matchingResults.push(matchingPost)
      }
    }
  }

  return matchingResults
}

function escapeHtml(string) {
  var entityMap = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': '&quot;',
    "'": '&#39;',
    "/": '&#x2F;'
  }

  return String(string).replace(/[&<>"'\/]/g, function (s) {
    return entityMap[s];
  })
}

},{}]},{},[1]);
